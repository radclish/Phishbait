<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Email Templates"/>
	<meta property="og:description" content="Modern solutions to phishing attacks." />
	<meta property="og:image" content="images/PhishBait Logo Trimmed Glow.png" />
	<meta property="og:url" content="https://phishbait.org/email-templates.php" />
	<meta name="twitter:card" content="summary_large_image">

    <!-- Webpage Title -->
    <title>PhishBait - Email Templates</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	<link rel="stylesheet" href="css/carousel.css">
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    <div id="page-container">
		<div id="content-wrap">
    
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.php"><img src="images/PhishBait Logo Trimmed Glow.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
					<li class="nav-item">
                        <a class="nav-link page-scroll" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.php">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.php">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-modules.php">Training Modules</a>
                    </li>
					<li class="nav-item">
						<div class="dropdown">
						<button class="btn btn-outline-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
						  Hello, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>
						</button>
						<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						  <li><a class="dropdown-item" href="reset-password.php">Settings</a></li>
						  <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
						</ul>
					  </div>
					</li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="headerSmall" style="height: 2vw">
        <div class="ocean" style="height: 2vw">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
    </div>
	
	
	<div class="centerTextDiv">
		<h1 class="h1-large" style="padding-bottom: 1em">Email Templates</h1>
	</div>
	<div class="centerTextDiv" style="padding-bottom: 1em">
		<p class="p-large" style="width:50%">Our email templates allow you to access dozens of hand crafted emails designed to simulate a phishing email.
			<br>Choose from one of the emails below, and click on the learn more to see a preview.
			<br>
			<br>Please note: Users must be signed in to download the templates. 
		</p>
	</div>
			
		<!-- Corporate Emails -->
        <div class="corporate-emails" style="padding-top: 1em !important">
        	<div class="container-fluid">
				<div class="centerTextDiv">
					<h1 class="h1-large">Corporate Templates</h1>
				</div>
				<div class="centerTextDiv">
					<hr style="height:2px; width:33%; border-width:9px; border-color: #02DAC5; opacity: 1.00; padding-bottom: 1em">
				</div>
        		<div id="carousel-corporate" class="carousel slide" data-ride="carousel" data-interval="false">
        			<div class="carousel-inner carousel-inner1 row w-75 mx-auto" role="listbox">
            			<div class="carousel-item carousel-item1 col-12 col-sm-6 col-md-4 active">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/job.png" class="img-fluid mx-auto d-block wh-150" alt="Job Icon">
									<h4 class="emailCenterTitle">Job Offer<br>Email</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-1">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item1 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/password.png" class="img-fluid mx-auto d-block wh-150" alt="Password Icon">
									<h4 class="emailCenterTitle">Password<br>Expired</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-2">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item1 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/ceo.png" class="img-fluid mx-auto d-block wh-150" alt="CEO Icon">
									<h4 class="emailCenterTitle">CEO<br>Fraud</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-3">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item1 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/job.png" class="img-fluid mx-auto d-block wh-150" alt="Job Icon">
									<h4 class="emailCenterTitle">Job Offer<br>Email</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-1">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item1 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/password.png" class="img-fluid mx-auto d-block wh-150" alt="Password Icon">
									<h4 class="emailCenterTitle">Password<br>Expired</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-2">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item1 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/ceo.png" class="img-fluid mx-auto d-block wh-150" alt="CEO Icon">
									<h4 class="emailCenterTitle">CEO<br>Fraud</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-3">Learn More</a></div>
								</div>
							</div>
						</div>
						
						
						<!--<div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
							<img src="images/backgrounds/7.jpg" class="img-fluid mx-auto d-block" alt="img7">
						</div>
						<div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
							<img src="images/backgrounds/8.jpg" class="img-fluid mx-auto d-block" alt="img8">
						</div>-->
						
        			</div>
        			<a class="carousel-control-prev" href="#carousel-corporate" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#carousel-corporate" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
        		</div>
        	</div>
        </div>
		
            
		<!-- Government Emails -->
        <div class="government-emails">
        	<div class="container-fluid">
				<div class="centerTextDiv">
					<h1 class="h1-large">Government Templates</h1>
				</div>
				<div class="centerTextDiv">
					<hr style="height:2px; width:33%; border-width:9px; border-color: #02DAC5; opacity: 1.00; padding-bottom: 1em">
				</div>
        		<div id="carousel-government" class="carousel slide" data-ride="carousel" data-interval="false">
        			<div class="carousel-inner carousel-inner2 row w-75 mx-auto" role="listbox">
            			<div class="carousel-item carousel-item2 col-12 col-sm-6 col-md-4 active">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/donation.png" class="img-fluid mx-auto d-block wh-150" alt="Donation Icon">
									<h4 class="emailCenterTitle">Donation<br>Scam</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-4">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item2 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/irs.png" class="img-fluid mx-auto d-block wh-150" alt="IRS Icon">
									<h4 class="emailCenterTitle">IRS<br>Scam</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-5">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item2 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/loan.png" class="img-fluid mx-auto d-block wh-150" alt="Loan Icon">
									<h4 class="emailCenterTitle">Loan<br>Confirmation</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-6">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item2 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/donation.png" class="img-fluid mx-auto d-block wh-150" alt="Donation Icon">
									<h4 class="emailCenterTitle">Donation<br>Scam</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-4">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item2 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/irs.png" class="img-fluid mx-auto d-block wh-150" alt="IRS Icon">
									<h4 class="emailCenterTitle">IRS<br>Scam</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-5">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item2 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/loan.png" class="img-fluid mx-auto d-block wh-150" alt="Loan Icon">
									<h4 class="emailCenterTitle">Loan<br>Confirmation</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-6">Learn More</a></div>
								</div>
							</div>
						</div>
						
						
						
						<!--<div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
							<img src="images/backgrounds/7.jpg" class="img-fluid mx-auto d-block" alt="img7">
						</div>
						<div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
							<img src="images/backgrounds/8.jpg" class="img-fluid mx-auto d-block" alt="img8">
						</div>-->
						
        			</div>
        			<a class="carousel-control-prev" href="#carousel-government" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#carousel-government" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
        		</div>
        	</div>
        </div>
            
        <!-- Consumer Emails -->
        <div class="consumer-emails" style="padding-bottom: 100px">
        	<div class="container-fluid">
				<div class="centerTextDiv">
					<h1 class="h1-large">Consumer Templates</h1>
				</div>
				<div class="centerTextDiv"> 
					<hr style="height:2px; width:33%; border-width:9px; border-color: #02DAC5; opacity: 1.00; padding-bottom: 1em">
				</div>
        		<div id="carousel-consumer" class="carousel slide" data-ride="carousel" data-interval="false">
        			<div class="carousel-inner carousel-inner3 row w-75 mx-auto" role="listbox">
            			<div class="carousel-item carousel-item3 col-12 col-sm-6 col-md-4 active">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/venmo.png" class="img-fluid mx-auto d-block wh-150" alt="Venmo Icon">
									<h4 class="emailCenterTitle">Venmo<br>Scam</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-7">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item3 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/facebook.png" class="img-fluid mx-auto d-block wh-150" alt="Facebook Icon">
									<h4 class="emailCenterTitle">Facebook<br>Login</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-8">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item3 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/bank.png" class="img-fluid mx-auto d-block wh-150" alt="Bank Icon">
									<h4 class="emailCenterTitle">Fifth Third<br>Bank</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-9">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item3 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/amazon.png" class="img-fluid mx-auto d-block wh-150" alt="Amazon Icon">
									<h4 class="emailCenterTitle">Amazon Account<br>Suspended</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-10">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item3 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/southwest.png" class="img-fluid mx-auto d-block wh-150" alt="Airline Icon">
									<h4 class="emailCenterTitle">Southwest Airlines<br>Giveaway</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-11">Learn More</a></div>
								</div>
							</div>
						</div>
						<div class="carousel-item carousel-item3 col-12 col-sm-6 col-md-4">
							<div class="emailFilterDivCarousel Corporate Emails">
								<div class="emailTextContainer mx-auto d-block" >
									<img src="images/icons/netflix.png" class="img-fluid mx-auto d-block wh-150" alt="Netflix Icon">
									<h4 class="emailCenterTitle">Netflix<br>Password Reset</h4>
									<div class="emailButtonContainerCarousel"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-12">Learn More</a></div>
								</div>
							</div>
						</div>
						
						
						
						
        			</div>
        			<a class="carousel-control-prev" href="#carousel-consumer" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#carousel-consumer" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
        		</div>
        	</div>
        </div>
			
			
			
	
	<!-- Lightboxes -->
    <!-- Example 1 -->
	<div id="email-lightbox-1" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/jobofferemail.png" width="100%" alt="Netflix Password Reset"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Job Offer Email</h3>
				<hr>
                <p>Designed to simulate a job offer from another company. Can use our predefined job or you can edit it match a specific employee. This is designed to get the target to give out person identifiable information data. After importing to a campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for internal communication scams.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Corporate Emails/Job Offer Email/Job Offer Email Template.zip" download="Email Template - Job Offer">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 1 -->
    <!-- Example 2 -->
	<div id="email-lightbox-2" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/companyaccountpasswordexpired.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Company Account Password Expired</h3>
				<hr>
                <p>Designed to simulate an internal email from your company saying that you need to update your password. This email prompts the user into clicking on the link to change their password. After importing to the campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for internal account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Corporate Emails/Company Account Password Expired/Corporate Password Expired.zip" download="Email Template - Corporate Account Password Expiration">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 2 -->
	<!-- Example 3 -->
	<div id="email-lightbox-3" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:200%; width:100%; vertical-align: middle; " src="images/ceofraud.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>CEO Fruad</h3>
				<hr>
                <p>Designed to simulate an email from the CEO of your company asking you to pay an invoice. This email pressures the user into paying an invoice without investigation due to the “CEO” asking for it done personally. After importing to the campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for internal account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Corporate Emails/CEO Fraud/CEO Fraud Email Template.zip" download="Email Template - CEO Fraud">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 3 -->
	<!-- Example 4 -->
	<div id="email-lightbox-4" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/donationscam.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Donation Scam</h3>
				<hr>
                <p>Designed to simulate an email from an election donation collector. This is designed to have you click on a link as well as donate money directly which gives the attacker direct access to credit card information. After importing to the campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Government Emails/Donation Scam/Election Donation Scam.zip" download="Email Template - Donation Scam">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 4 -->
	<!-- Example 5 -->
	<div id="email-lightbox-5" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/irsscam.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>IRS Scam</h3>
				<hr>
                <p>Designed to simulate an email from the IRS claiming they owe you money. This is designed to have you click on a link as well as give up your banking information. After importing to a service on the campaign guide, you are able to track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for government account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Government Emails/IRS Scam/IRS Tax Refund.zip" download="Email Template - IRS Scam">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 5 -->
	<!-- Example 6 -->
	<div id="email-lightbox-6" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/loanconfirmation.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Loan Confirmation</h3>
				<hr>
                <p>This template is designed to simulate an email from a loan service providing the user with a loan request summary. This is designed to shock you into clicking on a link. After importing to a service on the campaign guide, you are able to track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Loan Confirmation/Email Template Loan Confirmation.zip" download="Email Template - Loan Confirmation">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 6 -->
	<!-- Example 7 -->
	<div id="email-lightbox-7" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/venmo.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Venmo</h3>
				<hr>
                <p>This template simulates a user getting an email from Venmo asking to reset their password. It seems like the email is coming from their support team and even provides a place to report scam. After importing to the campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Venmo/Venmo Password Change Request.zip" download="Email Template - Venmo Password Change">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 7 -->
	<!-- Example 8 -->
	<div id="email-lightbox-8" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/facebooksuspiciouslogin.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Facebook Suspicious Login</h3>
				<hr>
                <p>Designed to simulate a warning about a suspicious login on a new device from Facebook. This template is trying to get the user to click a link to reset their password. After importing to a service on the campaign guide, you are able to track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Facebook Suspicious Login/Facebook Suspicious Account Activity.zip" download="Email Template - Facebook Suspicious Login">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 8 -->
	<!-- Example 9 -->
	<div id="email-lightbox-9" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/fifththirdbank.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Fifth Third Bank</h3>
				<hr>
                <p>This template is designed to simulate a suspicious charge on a Fifth Third Bank card. It is designed to mirror a real email from Fifth Third so that the user clicks on the link. After importing to the campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Fifth Third Bank/Suspicious Purchase Notice Fifth Third.zip" download="Email Template - Fifth Third Bank">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 9 -->
	<!-- Example 10 -->
	<div id="email-lightbox-10" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/amazonaccountsuspended.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Amazon Account Suspended</h3>
				<hr>
                <p>Designed to simulate Amazon sending a report of fraudulent activity on your account. This template mirrors a real email from Amazon support and prompts the user to file a claim. After importing to the campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Amazon Account Suspended/Amazon Account Suspended.zip" download="Email Template - Amazon Account Suspended">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 10 -->
	<!-- Example 11 -->
	<div id="email-lightbox-11" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/southwestairlinesgiveaway.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Southwest Airlines Giveaway</h3>
				<hr>
                <p>This template simulates a user getting an email saying they have been selected to receive a $250 gift card. This template prompts the user to click a link for a survey to receive the gift card. After importing to the campaign service, you can track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Southwest Airlines Giveaway/Southwest Airlines Giveaway Email.zip" download="Email Template - Southwest Airlines Giveaway">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 11 -->
	<!-- Example 12 -->
	<div id="email-lightbox-12" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/netflixpasswordreset.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Netflix Account Password Reset</h3>
				<hr>
                <p>This template is designed to simulate a user receiving a Netflix password reset email. This template mirrors a real email from the Netflix support team. After importing the template to a service on the campaign guide page, you are able to track the results of this email.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Netflix Account Password Reset/Netflix Password Reset.zip" download="Email Template - Netflix Password Reset">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 12 -->
	
    <!-- end of lightboxes -->
		
	
	<script> 
		filterSelection("all")
		function filterSelection(c) {
		  var x, i;
		  x = document.getElementsByClassName("emailFilterDiv");
		  if (c == "all") c = "";
		  // Add the "show" class (display:block) to the filtered elements, and remove the "show" class from the elements that are not selected
		  for (i = 0; i < x.length; i++) {
			w3RemoveClass(x[i], "emailBtnShow");
			if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "emailBtnShow");
		  }
		}

		// Show filtered elements
		function w3AddClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			if (arr1.indexOf(arr2[i]) == -1) {
			  element.className += " " + arr2[i];
			}
		  }
		}

		// Hide elements that are not selected
		function w3RemoveClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			while (arr1.indexOf(arr2[i]) > -1) {
			  arr1.splice(arr1.indexOf(arr2[i]), 1);
			}
		  }
		  element.className = arr1.join(" ");
		}

		// Add active class to the current control button (highlight it)
		var btnContainer = document.getElementById("emailBtnContainer");
		var btns = btnContainer.getElementsByClassName("emailBtn");
		for (var i = 0; i < btns.length; i++) {
		  btns[i].addEventListener("click", function() {
			var current = document.getElementsByClassName("active");
			current[0].className = current[0].className.replace(" active", "");
			this.className += " active";
		  });
		}
	</script>

    </div> <!-- end of content-wrap -->
	<!-- Footer -->
	<footer id="footer">
		<div class="centerTextDiv bg-gray">
        <div class="container">
            <div class="row">
                <div class="col">
					<p class="p-small" style="margin-top:1rem"><a class="footer-link" href="privacy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> · <a class="footer-link" href="cookies.html" target="_blank" rel="noopener noreferrer">Cookie Policy</a></p>
					<p class="p-small">Assets gathered under <a class="footer-link" href="https://creativecommons.org/licenses/" target="_blank" rel="noopener noreferrer">Creative Commons Licenses</a> · Created for educational purposes only.</p>
                </div>
            </div>
        </div>
    </div>
	</footer>
	<!-- end of footer -->
		
	</div><!-- end of page container -->
    
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
	<script src="js/carousel.js"></script> <!-- Carousel scripts -->
	<script src="js/jquery.backstretch.js"></script>
</body>
</html>
