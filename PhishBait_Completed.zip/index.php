<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Home"/>
	<meta property="og:description" content="Modern solutions to phishing attacks." />
	<meta property="og:image" content="images/PhishBait Logo Trimmed Glow.png" />
	<meta property="og:url" content="https://phishbait.org/index.php" />
	<meta name="twitter:card" content="summary_large_image">

    <!-- Webpage Title -->
    <title>PhishBait - Home</title> 
    
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
    <link rel="icon" href="images/favicon.png">
	
</head>
<body data-spy="scroll" data-target=".fixed-top">
    <div id="page-container">
		<div id="content-wrap">
    
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.php"><img src="images/PhishBait Logo Trimmed Glow.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
					<li class="nav-item">
                        <a class="nav-link page-scroll" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.php">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.php">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-modules.php">Training Modules</a>
                    </li>
					
					<li class="nav-item">
						<div class="dropdown">
						<button class="btn btn-outline-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
						  Hello, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>
						</button>
						<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						  <li><a class="dropdown-item" href="reset-password.php">Settings</a></li>
						  <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
						</ul>
					  </div>
					</li>
                </ul>
            </div>
        </div>
    </nav>
	
	
	
	

    <!-- Header -->
    <div class="header">
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="text-container">
                        <h1 class="h1-large">The Future of <br> Phishing Awareness</h1>
                        <p class="p-large">Modern solutions to phishing attacks<br>Find out how to fight back against these phishing schemes</p>
                        <a class="btn-solid-lg page-scroll" href="#about">Learn More</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image-container">
                        <img class="img-fluid" src="images/infohook.png" alt="Info Hook Icon">
                    </div>
                </div>
            </div>
        </div>
    </div>


	<div class="indexContainer" id="about">
	  <div class="indexFilterDiv">
			<div class="indexTextContainer" >
				<i class="fas fa-question-circle"></i>
				<h4>What</h4>
				<p>Phishing is a cyber-attack where the target or targets receive a fraudulent email, text message, or phone call from the attacker who is posing as a legitimate entity to lure their targets into revealing personal information, such as credit card information or passwords</p>
			</div>
	  </div>
	  <div class="indexFilterDiv">
			<div class="indexTextContainer">
				<i class="fas fa-cogs"></i>
				<h4>How</h4>
				<p>The most common type of phishing attack is delivered through email. The sender generally poses as a legitimate sender and tries to gather personal information from the target using shock tactics. The goal of the email is to trick the user into clicking the link which will lead them to a fake website imitating a real site. The user then logs in, compromising their credentials.</p>
			</div>
	  </div>
	  <div class="indexFilterDiv">
			<div class="indexTextContainer">
				<i class="fas fa-bullseye"></i>
				<h4>Why</h4>
				<p>Phishing is so effective because users lack security awareness. Attackers will also rely on the sense of surprise. Not all users know what phishing is, so they don’t even know they are potential targets. Attackers will pick a time, such as work, where users are distracted. This gives attackers a better chance to catch a user in a phishing scheme.</p>
			</div>
	  </div>
	</div>	
	

    <!-- Details 2 -->
    <div id="EmailTemplates" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-5">
                    <div class="text-container">
                        <h2>Email Templates</h2>
                        <p>The Email Templates page contains a variety of specialized phishing email templates. The topics of the templates range from free downloads to shopping sites, making phising emails using them more enticing. These email templates will: </p>
                        <ul class="list-unstyled li-space-lg">
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Make sending out phising campaigns in your company easier</strong> </div>
                            </li>
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Help you send out more accurate phising campaigns</strong> </div>
                            </li>
                        </ul> 
                        <a class="btn-solid-reg" href="email-templates.php">Details</a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-7">
                    <div class="image-container-center">
                        <img class="img-fluid" src="images/emailTemplates.svg" alt="Email Templates Icon" style="filter: drop-shadow(-2px 4px 4px #585858)">
                    </div>
                </div>
            </div>
        </div>
    </div>
	
    <!-- Details 3 -->
    <div id="TrainingVideos" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-7">
                    <div class="image-container-center">
                        <img class="img-fluid" src="images/trainingVideos.svg" alt="Training Videos Icon" style="filter: drop-shadow(-2px 4px 4px #585858)">
                    </div>
                </div>
                <div class="col-lg-6 col-xl-5">
                    <div class="text-container">
                        <h2>Training Modules</h2>
                        <p>The Training Modules page contains a variety of training videos on phishing corosponding to the specific email templates.This is where employees will go after falling for a phising campaign sent out, or where they can go to better understand what phishing is. These modules will: </p>
                        <ul class="list-unstyled li-space-lg">
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Train employees on the dangers of phishing and how to prevent an attack  </strong></div>
                            </li>
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Provide better security for your company from phising attacks</strong> </div>
                            </li>
                        </ul> 
                        <a class="btn-solid-reg" href="training-modules.php">Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Invitation -->
    <div class="basic-6" style="background: #102a43">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container">
                        <h2 style="color: #FFFFFF">Who can use this information?</h2>
						<p style="color: #FFFFFF">Our training modules are open to the public, but are intended for <br>
						the end users of the organizations we work with. Email templates and<br>
						user data are restricted, allowing only organization's administrators access.</p>
                        <a class="btn-solid-lg" href="dashboard.php">Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<!-- Contact -->
    <div id="contact" class="form-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="h2-heading">Contact Us:</h2>
                    <p class="p-heading">Questions? Feel free to reach out through the contact form or <a class="blue no-line" href="mailto:team@phishbait.org">team@phishbait.org</a></p>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-container"> 
                        <form method="post" action="messagereceived.php">
                            <div class="form-group">
                                <input type="text" class="form-control-input" id="contactname" required>
                                <label class="label-control" for="contactname" name="contactname">Name</label>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control-input" id="contactemail" required>
                                <label class="label-control" for="contactemail" name="contactemail">Email</label>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control-textarea" id="contactmessage" required></textarea>
                                <label class="label-control" for="contactmessage" name="contactmessage">Your message</label>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="form-control-submit-button">Submit Message</button>
                            </div>
                        </form>
                    </div>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of form-1 -->
    <!-- end of contact -->
	
	
	
    </div> <!-- end of content-wrap -->
	<!-- Footer -->
	<footer id="footer">
		<div class="centerTextDiv bg-gray">
        <div class="container">
            <div class="row">
                <div class="col">
					<p class="p-small" style="margin-top:1rem"><a class="footer-link" href="privacy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> · <a class="footer-link" href="cookies.html" target="_blank" rel="noopener noreferrer">Cookie Policy</a></p>
					<p class="p-small">Assets gathered under <a class="footer-link" href="https://creativecommons.org/licenses/" target="_blank" rel="noopener noreferrer">Creative Commons Licenses</a> · Created for educational purposes only.</p>
                </div>
            </div>
        </div>
    </div>
	</footer>
	<!-- end of footer -->
		
	</div><!-- end of page container -->
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>
