<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Email Templates"/>
	<meta property="og:description" content="Modern solutions to phishing attacks." />
	<meta property="og:image" content="images/PhishBait Logo Trimmed Glow.png" />
	<meta property="og:url" content="https://phishbait.org/email-templates.php" />
	<meta name="twitter:card" content="summary_large_image">

    <!-- Webpage Title -->
    <title>PhishBait - Email Templates</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    <div id="page-container">
		<div id="content-wrap">
    
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.php"><img src="images/PhishBait Logo Trimmed Glow.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
					<li class="nav-item">
                        <a class="nav-link page-scroll" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.php">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.php">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-videos.php">Training Videos</a>
                    </li>
					<li class="nav-item">
						<div class="dropdown">
						<button class="btn btn-outline-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
						  Hello, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>
						</button>
						<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						  <li><a class="dropdown-item" href="reset-password.php">Settings</a></li>
						  <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
						</ul>
					  </div>
					</li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="header" style="height: 2vw">
        <div class="ocean" style="height: 2vw">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
    </div>
	
	
	<div class="centerTextDiv">
		<h1 class="h1-large" style="padding-bottom: 1em">Email Templates</h1>
	</div>
	<div class="centerTextDiv" style="padding-bottom: 1em">
		<p class="p-large" style="width:50%">Our email templates allow you to access dozens of hand crafted emails designed to simulate a phishing email.
			<br>Choose from one of the emails below, and click on the learn more to see a preview.
			<br>
			<br>Please note: Users must be signed in to download the templates. </p>
	</div>
	<!-- Control buttons -->
	<div class="centerTextDiv" style="padding-bottom: 4em">
		<div id="emailBtnContainer">
		  <button class="emailBtn active" onclick="filterSelection('all')"> Show all</button>
		</div>
		<div class="dropdown">
		  <button class="emailBtn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			Filter Templates
		  </button>
		  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
			<a class="dropdown-item" onclick="filterSelection('Corporate Emails')"> Corporate Emails</a>
			<a class="dropdown-item" onclick="filterSelection('Government Emails')"> Government Emails</a>
			<a class="dropdown-item" onclick="filterSelection('Consumer Emails')"> Consumer Emails</a>
		  </div>
		</div>
	</div>

	<!-- The filterable elements. Note that some have multiple class names (this can be used if they belong to multiple categories) -->
	<div class="emailContainer">
	  <div class="emailFilterDiv Corporate Emails">
			<div class="emailTextContainer">
				<h4>Job Offer Email</h4>
				<p>Designed to simulate a Netflix password reset email. This template mirrors a real email from Netflix support. After importing to the campaign service, you are able to track the results of this email. Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies guidelines on security testing before using.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-1">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Corporate Emails">
			<div class="emailTextContainer">
				<h4>Company Account Password Expired</h4>
				<p>Designed to simulate an email notification about a change to the company COVID-19 guidelines and policies. Filler text about phishing. Text about phishing information would go in the place of this text.Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies guidelines on security testing before using.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-2">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Corporate Emails">
			<div class="emailTextContainer">
				<h4>CEO Fraud</h4>
				<p>This is a customizble template for simulating your company's internal password reset emails. Logos and text can be adjusted to mirror the company branding. Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies guidelines on security testing before using. Filler text for line formatting.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-3">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Government Emails">
			<div class="emailTextContainer">
				<h4>Donation Scam</h4>
				<p>Filler text about phishing. Text about phishing information would go in the place of this text. Filler text about phishing. Text about phishing information would go in the place of this text. Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies guidelines on security testing before using.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-4">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Government Emails">
			<div class="emailTextContainer">
				<h4>IRS Scam</h4>
				<p>Filler text about phishing. Text about phishing information would go in the place of this text. Filler text about phishing. Text about phishing information would go in the place of this text. Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies guidelines on security testing before using.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-5">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Consumer Emails">
			<div class="emailTextContainer">
				<h4>Loan Confirmation</h4>
				<p>Filler text about phishing. Text about phishing information would go in the place of this text. Filler text about phishing. Text about phishing information would go in the place of this text. Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies guidelines on security testing before using.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-6">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Consumer Emails">
			<div class="emailTextContainer">
				<h4>Venmo</h4>
				<p>This template simulates a user getting an email from Venmo asking to reset their password. It seems like the email is coming from their support team and even provides a place to report scam. After importing to the campaign service, you can track the results of this email.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-7">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Consumer Emails">
			<div class="emailTextContainer">
				<h4>Facebook Suspicious Login</h4>
				<p>Designed to simulate a warning about a suspicious login on a new device from Facebook. This template is trying to get the user to click a link to reset their password. After importing to the campaign service, you can track the results of this email.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-8">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Consumer Emails">
			<div class="emailTextContainer">
				<h4>Fifth Third Bank</h4>
				<p>This template is designed to simulate a suspicious charge on a Fifth Third Bank card. It is designed to mirror a real email from Fifth Third so that the user clicks on the link.  After importing to the campaign service, you can track the results of this email.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-9">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Consumer Emails">
			<div class="emailTextContainer">
				<h4>Amazon Account Suspended</h4>
				<p>Designed to simulate Amazon sending a report of fraudulent activity on your account. This template mirrors a real email from Amazon support and prompts the user to file a claim. After importing to the campaign service, you can track the results of this email.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-10">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Consumer Emails">
			<div class="emailTextContainer">
				<h4>Southwest Airlines Giveaway</h4>
				<p>This template simulates a user getting an email saying they have been selected to receive a $250 gift card. This template prompts the user to click a link for a survey to receive the gift card. After importing to the campaign service, you can track the results of this email.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-11">Learn More</a></div>
			</div>
	  </div>
	  <div class="emailFilterDiv Consumer Emails">
			<div class="emailTextContainer">
				<h4>Netflix Account Password Reset</h4>
				<p>Designed to simulate a Netflix password reset email. This template mirrors a real email from Netflix support. After importing to the campaign service, you can track the results of this email.</p>
				<div class="emailButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#email-lightbox-12">Learn More</a></div>
			</div>
	  </div>
	</div>
	
	<!-- Lightboxes -->
    <!-- Example 1 -->
	<div id="email-lightbox-1" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/jobofferemail.png" width="100%" alt="Netflix Password Reset"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Job Offer Email</h3>
				<hr>
                <p>Simulate a password reset request from the popular streaming service Netflix. A surprising amount of people use company emails for personal accounts. This template mirrors the emails received from Netflix when a user requests to reset their password.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd part account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Corporate Emails/Job Offer Email/Job Offer Email Template.zip" download="Email Template - Job Offer">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 1 -->
    <!-- Example 2 -->
	<div id="email-lightbox-2" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/companyaccountpasswordexpired.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Company Account Password Expired</h3>
				<hr>
                <p>Simulate a notification of an update to the company COVID-19 guidelines. Current events and national news are common phishing topics, and this training will help your users know what to look for.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test current event topics.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Corporate Emails/Company Account Password Expired/Corporate Password Expired.zip" download="Email Template - Corporate Account Password Expiration">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 2 -->
	<!-- Example 3 -->
	<div id="email-lightbox-3" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:200%; width:100%; vertical-align: middle; " src="images/ceofraud.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>CEO Fruad</h3>
				<hr>
                <p>Simulate a password reset from your company. This template can be customized with your internal logos and branding.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test internal account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Internal Accounts</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Corporate Emails/CEO Fraud/CEO Fraud Email Template.zip" download="Email Template - CEO Fraud">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 3 -->
	<!-- Example 4 -->
	<div id="email-lightbox-4" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/donationscam.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Donation Scam</h3>
				<hr>
                <p>This is a few sentences about the template. More information can be added below as well.</p>
                <h4>Testing For:</h4>
                <p>This is a few sentences about the contents of the template. More information can be added below as well.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 1</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 2</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 3</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 4</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Government Emails/Donation Scam/Election Donation Scam.zip" download="Email Template - Donation Scam">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 4 -->
	<!-- Example 5 -->
	<div id="email-lightbox-5" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/irsscam.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>IRS Scam</h3>
				<hr>
                <p>This is a few sentences about the template. More information can be added below as well.</p>
                <h4>Testing For:</h4>
                <p>This is a few sentences about the contents of the template. More information can be added below as well.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 1</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 2</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 3</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 4</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Government Emails/IRS Scam/IRS Tax Refund.zip" download="Email Template - IRS Scam">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 5 -->
	<!-- Example 6 -->
	<div id="email-lightbox-6" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/loanconfirmation.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Loan Confirmation</h3>
				<hr>
                <p>This is a few sentences about the template. More information can be added below as well.</p>
                <h4>Testing For:</h4>
                <p>This is a few sentences about the contents of the template. More information can be added below as well.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 1</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 2</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 3</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Main point 4</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Loan Confirmation/Email Template Loan Confirmation.zip" download="Email Template - Loan Confirmation">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 6 -->
	<!-- Example 7 -->
	<div id="email-lightbox-7" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/venmo.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Venmo</h3>
				<hr>
                <p>Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies’ guidelines on security testing before using.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Venmo/Venmo Password Change Request.zip" download="Email Template - Venmo Password Change">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 7 -->
	<!-- Example 8 -->
	<div id="email-lightbox-8" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/facebooksuspiciouslogin.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Facebook Suspicious Login</h3>
				<hr>
                <p>Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies’ guidelines on security testing before using.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Facebook Suspicious Login/Facebook Suspicious Account Activity.zip" download="Email Template - Facebook Suspicious Login">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 8 -->
	<!-- Example 9 -->
	<div id="email-lightbox-9" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/fifththirdbank.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Fifth Third Bank</h3>
				<hr>
                <p>Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies’ guidelines on security testing before using.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Fifth Third Bank/Suspicious Purchase Notice Fifth Third.zip" download="Email Template - Fifth Third Bank">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 9 -->
	<!-- Example 10 -->
	<div id="email-lightbox-10" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/amazonaccountsuspended.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Amazon Account Suspended</h3>
				<hr>
                <p>Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies' guidelines on security testing before using.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Amazon Account Suspended/Amazon Account Suspended.zip" download="Email Template - Amazon Account Suspended">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 10 -->
	<!-- Example 11 -->
	<div id="email-lightbox-11" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/southwestairlinesgiveaway.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Southwest Airlines Giveaway</h3>
				<hr>
                <p>Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies' guidelines on security testing before using.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Southwest Airlines Giveaway/Southwest Airlines Giveaway Email.zip" download="Email Template - Southwest Airlines Giveaway">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 11 -->
	<!-- Example 12 -->
	<div id="email-lightbox-12" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/netflixpasswordreset.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Netflix Account Password Reset</h3>
				<hr>
                <p>Please note: This template is for internal testing campaigns only. This template is not allowed to be used for anything other than security testing with permission from the receiver. Please refer to your companies' guidelines on security testing before using.</p>
                <h4>Testing For:</h4>
                <p>This template is designed to test for 3rd party account notices.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Topic Training</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Suspicious Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Illegitimate Sender</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="emailtemplates/Consumer Emails/Netflix Account Password Reset/Netflix Password Reset.zip" download="Email Template - Netflix Password Reset">Download Template</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 12 -->
	
    <!-- end of lightboxes -->
		
	
	<script> 
		filterSelection("all")
		function filterSelection(c) {
		  var x, i;
		  x = document.getElementsByClassName("emailFilterDiv");
		  if (c == "all") c = "";
		  // Add the "show" class (display:block) to the filtered elements, and remove the "show" class from the elements that are not selected
		  for (i = 0; i < x.length; i++) {
			w3RemoveClass(x[i], "emailBtnShow");
			if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "emailBtnShow");
		  }
		}

		// Show filtered elements
		function w3AddClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			if (arr1.indexOf(arr2[i]) == -1) {
			  element.className += " " + arr2[i];
			}
		  }
		}

		// Hide elements that are not selected
		function w3RemoveClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			while (arr1.indexOf(arr2[i]) > -1) {
			  arr1.splice(arr1.indexOf(arr2[i]), 1);
			}
		  }
		  element.className = arr1.join(" ");
		}

		// Add active class to the current control button (highlight it)
		var btnContainer = document.getElementById("emailBtnContainer");
		var btns = btnContainer.getElementsByClassName("emailBtn");
		for (var i = 0; i < btns.length; i++) {
		  btns[i].addEventListener("click", function() {
			var current = document.getElementsByClassName("active");
			current[0].className = current[0].className.replace(" active", "");
			this.className += " active";
		  });
		}
	</script>

    </div> <!-- end of content-wrap -->
	<!-- Footer -->
	<footer id="footer">
		<div class="centerTextDiv bg-gray">
        <div class="container">
            <div class="row">
                <div class="col">
					<p class="p-small" style="margin-top:1rem"><a class="footer-link" href="privacy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> · <a class="footer-link" href="cookies.html" target="_blank" rel="noopener noreferrer">Cookie Policy</a></p>
					<p class="p-small">Assets gathered under <a class="footer-link" href="https://creativecommons.org/licenses/" target="_blank" rel="noopener noreferrer">Creative Commons Licenses</a> · Created for educational purposes only.</p>
                </div>
            </div>
        </div>
    </div>
	</footer>
	<!-- end of footer -->
		
	</div><!-- end of page container -->
    
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>
