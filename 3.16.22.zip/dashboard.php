<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Dashboard"/>
	<meta property="og:description" content="Modern solutions to phishing attacks." />
	<meta property="og:image" content="images/PhishBait Logo Trimmed Glow.png" />
	<meta property="og:url" content="https://phishbait.org/dashboard.php" />
	<meta name="twitter:card" content="summary_large_image">


    <!-- Webpage Title -->
    <title>PhishBait - Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap5.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
    <link rel="icon" href="images/favicon.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
    <style>
        @media (max-width: 767.98px) {
            .sidebar {
                top: 11.5rem;
                padding: 0;
            }
        }
            
        .navbar {
            box-shadow: inset 0 -1px 0 rgba(0, 0, 0, .1);
        }

        @media (min-width: 767.98px) {
            .navbar {
                top: 0;
                position: sticky;
                z-index: 999;
            }
        }

        .sidebar .nav-link {
            color: #333;
        }

        .sidebar .nav-link.active {
            color: #0d6efd;
        }
		
		
		.pagination li:hover{
    cursor: pointer;
}
		table tbody tr {
			display: none;
		}
    </style>
</head>
<body style="height: 100%">
	<div id="page-container">
		<div id="content-wrap">
		
    <nav class="navbar navbar-dark bg-navy p-3">
        <div class="d-flex col-12 col-md-3 col-lg-2 mb-2 mb-lg-0 flex-wrap flex-md-nowrap justify-content-between">
            <a class="navbar-brand logo-image page-scroll" href="index.php"><img src="images/PhishBait Logo Trimmed Glow.png" alt="alternative" style="height:100%"></a>
            <button class="navbar-toggler d-md-none collapsed mb-3" type="button" data-toggle="collapse" data-target="#sidebar" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
		<div>
			<ul class="list-group list-group-horizontal">
				<li class="list-group-item-nav">
					<a class="nav-link page-scroll" href="dashboard.php">Dashboard</a>
				</li>
				<li class="list-group-item-nav">
					<a class="nav-link page-scroll" href="campaign-guide.php">Campaign Guide</a>
				</li>
				<li class="list-group-item-nav">
					<a class="nav-link page-scroll" href="email-templates.php">Email Templates</a>
				</li>
				<li class="list-group-item-nav">
					<a class="nav-link page-scroll" href="training-videos.php">Training Videos</a>
				</li>
				<li class="list-group-item-nav">
					<div class="dropdown">
						<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
						  Hello, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>
						</button>
						<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						  <li><a class="dropdown-item" href="reset-password.php">Settings</a></li>
						  <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
						</ul>
					  </div>
				</li>
			</ul>
		</div>
    </nav>

    <div class="container-fluid">
        <div class="row">
			<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-navy-alt sidebar collapse" style="padding: 55px 12px 12px 12px; border-top: solid #02DAC5;">
                <div class="position-sticky">
					<div class="centerTextDiv">
						<ul class="list-group">
							<div class="centerTextDiv">
							  <div class="profile-pic"><?php echo htmlspecialchars($_SESSION["firstname"][0]); ?><?php echo htmlspecialchars($_SESSION["lastname"][0]); ?></div>
							</div>
							<li class="list-group-item-sidebar-title">
								<p class="sidebar-title"><br><?php echo htmlspecialchars($_SESSION["firstname"]); ?>&nbsp;<?php echo htmlspecialchars($_SESSION["lastname"]); ?></p>
							</li>
							<li class="list-group-item-sidebar">
								<p class="fw-bold"><?php echo htmlspecialchars($_SESSION["org"]); ?> <br>Security Analyst</p>
							</li>
						</ul>
					</div>
				</div>
				
				<div class="position-sticky">
					<div class="centerTextDiv">
						<ul class="list-group">
							<li class="list-group-item-sidebar-subtitle">
								<p class="fw-bold">User Test Log:</p>
							</li>
							
							<li class='list-group-item-sidebar d-flex justify-content-between align-items-start'>
								<div class='ms-2 me-auto'>
								  <div class='fw-bold'>User Name</div>
							 	</div>
								  <span class='badge rounded-pill'>Quiz Average</span>
							  </li>
							
							<?php

								require_once "config.php";
								$sql = ("SELECT `email`, `firstname`, `lastname`, AVG(`resultpercent`),`timestamp` FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' GROUP BY firstname, lastname LIMIT 7");

								$result = $link->query($sql);
								$usernames = array();
								  if ($result->num_rows > 0) {
								  // output data of each row
								  while ($row = mysqli_fetch_array($result)) {
									$usernames[] = $row;
									  echo "<li class='list-group-item-sidebar d-flex justify-content-between align-items-start'>";
									  echo "<div class='ms-2 me-auto'>";
									  echo "<div class='fw-bold'>" . $row['firstname'] . " " . $row['lastname'] . "&emsp;</div>";
									  echo "</div>";

									  $useraverage=number_format((float)$row['AVG(`resultpercent`)'], 2, '.', '');
									  echo "<span class='badge rounded-pill'>" . $useraverage . "%" .  "</span>";
									  echo "</li>";
								  }
									} else {
								  	echo "0 results";
									}
							   ?>
							<div style="display: none" id="expandNames">
							<?php

								require_once "config.php";
								$sql = ("SELECT `email`, `firstname`, `lastname`, AVG(`resultpercent`),`timestamp` FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' GROUP BY firstname, lastname LIMIT 500 OFFSET 7");

								$result = $link->query($sql);
								$usernames = array();
								  if ($result->num_rows > 0) {
								  // output data of each row
								  while ($row = mysqli_fetch_array($result)) {
									$usernames[] = $row;
									  echo "<li class='list-group-item-sidebar d-flex justify-content-between align-items-start'>";
									  echo "<div class='ms-2 me-auto'>";
									  echo "<div class='fw-bold'>" . $row['firstname'] . " " . $row['lastname'] . "&emsp;</div>";
									  echo "</div>";

									  $useraverage=number_format((float)$row['AVG(`resultpercent`)'], 2, '.', '');
									  echo "<span class='badge rounded-pill'>" . $useraverage . "%" .  "</span>";
									  echo "</li>";
								  }
									} else {
								  	echo "0 results";
									}
							   ?>
							</div>
								<input type="button" id="namesButton" class="btn btn-secondary" onclick="showHiddenList()" value="See All"></input>
								<script>
									function showHiddenList() {
									  var x = document.getElementById("expandNames");
									  var y = document.getElementById("namesButton");
									  if (x.style.display === "none") {
										x.style.display = "block";
										y.value = "Close Expanded"
									  } else {
										x.style.display = "none";
										y.value = "See All"
										
									  }
									}
								</script>
							
							
							
							
						</ul>
					</div>
                </div>
            </nav>
			
			
            <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4 py-4" style="height:100%">
                <h1 class="h2"><?php echo htmlspecialchars($_SESSION["org"]); ?> Dashboard</h1>
                <p>This is the administration dashboard for your organization's PhishBait data.</p>
                <div class="row my-4">	
					<?php
							require_once "config.php";
							$sql4 = ("Select count(`QuizAttemptID`) from QuizAttempt WHERE `organization` ='" . $_SESSION['org'] . "'");
							$result4 = $link->query($sql4);
							$attemptcount = array();
							if ($result4->num_rows > 0) {
							  while ($row = mysqli_fetch_array($result4)) {
								$attemptcount[] = $row;
							  }
								$currentattemptcount = ($attemptcount[0][1]);
								$currentattemptcount = var_export($attemptcount[0][1], true);
							} else {
							  echo "0 results";
							}
							
				   ?>
					
					<?php

							require_once "config.php";
							$sql5 = ("Select count(QuizAttemptID) from QuizAttempt WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN CURRENT_DATE - INTERVAL 30 DAY AND CURRENT_DATE ORDER BY `timestamp` DESC");
							$result5 = $link->query($sql5);
							$last30days = array();
							if ($result5->num_rows > 0) {
							  while ($row = mysqli_fetch_array($result5)) {
								$last30days[] = $row;
							  }
								$currentlast30days = ($last30days[0][1]);
								$currentlast30days = var_export($last30days[0][1], true);
							} else {
							  echo "0 results";
							}
							
				   ?>
                    <div class="col-12 col-md-6 col-lg-3 mb-4 mb-lg-0">
                        <div class="card">
                            <h5 class="card-header">Quiz Attempts</h5>
                            <div class="card-body">
                              <h5 class="card-title"><?php echo htmlspecialchars($attemptcount[0][0]); ?></h5>
                              <p class="card-text">Total # of quiz attempts.</p>
                              <p class="card-text text-success">+<?php echo htmlspecialchars($last30days[0][0]); ?> over the past 30 days.</p>
                            </div>
                          </div>
                    </div>
					
					<?php

							require_once "config.php";					
							$sql3 = ("Select count(DISTINCT `email`) from QuizAttempt WHERE `organization` ='" . $_SESSION['org'] . "'");
							$result3 = $link->query($sql3);
							$usercount = array();

							if ($result3->num_rows > 0) {
							  while ($row = mysqli_fetch_array($result3)) {
								$usercount[] = $row;
							  }
								$currentusercount = ($usercount[0][1]);
								$currentusercount = var_export($usercount[0][1], true);
							} else {
							  echo "0 results";
							}
							
				   ?>
					
					<?php

							require_once "config.php";
							$sql5 = ("Select count(DISTINCT `email`) from QuizAttempt WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN CURRENT_DATE - INTERVAL 30 DAY AND CURRENT_DATE ORDER BY `timestamp` DESC");
							$result5 = $link->query($sql5);
							$userslast30days = array();

							if ($result5->num_rows > 0) {
							  while ($row = mysqli_fetch_array($result5)) {
								$userslast30days[] = $row;
							  }
								$currentuserslast30days = ($userslast30days[0][1]);
								$currentuserslast30days = var_export($userslast30days[0][1], true);
							} else {
							  echo "0 results";
							}
				   ?>
                    <div class="col-12 col-md-6 mb-4 mb-lg-0 col-lg-3">
                        <div class="card">
                            <h5 class="card-header">User Count</h5>
                            <div class="card-body">
                              <h5 class="card-title"><?php echo htmlspecialchars($usercount[0][0]); ?></h5>
                              <p class="card-text">Total # of users.</p>
                              <p class="card-text text-success">+<?php echo htmlspecialchars($userslast30days[0][0]); ?> unique users over the past 30 days.</p>
                            </div>
                          </div>
                    </div>
					
					<?php

							require_once "config.php";
							$sql6 = ("SELECT AVG(`resultpercent`) FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "'");
							$result6 = $link->query($sql6);
							$successrate = array();

							if ($result6->num_rows > 0) {
							  while ($row = mysqli_fetch_array($result6)) {
								$successrate[] = $row;
							  }
								$currentsuccessrate = ($successrate[0][1]);
								$currentsuccessrate = var_export($successrate[0][1], true);
							} else {
							  echo "0 results";
							}
							$x=67;  
							$y=number_format((float)$successrate[0][0], 2, '.', '');  
							$z=$x-$y;
							$successratediff = number_format((float)$z, 2, '.', '');
				   ?>
					
					
					
                    <div class="col-12 col-md-6 mb-4 mb-lg-0 col-lg-3">
                        <div class="card">
                            <h5 class="card-header">Quiz Success Rate</h5>
                            <div class="card-body">
                              <h5 class="card-title"><?php echo htmlspecialchars($y); ?>%</h5>
                              <p class="card-text">Average of Quiz Results</p>
                              <p class="card-text text-danger"><?php echo htmlspecialchars($successratediff); ?>% below the passing rate.</p>
                            </div>
                          </div>
                    </div>
					
                    <div class="col-12 col-md-6 mb-4 mb-lg-0 col-lg-3">
                        <div class="card">
                            <h5 class="card-header">Title</h5>
                            <div class="card-body">
                              <h5 class="card-title">Subtitle</h5>
                              <p class="card-text">Statement line</p>
                              <p class="card-text text-success">More information goes here.</p>
                            </div>
                        </div>
                    </div>
                </div>
				
                <div class="row">
                    <div class="col-12 col-xl-8 mb-4 mb-lg-0">
                        <div class="card">
							<div class="card-header-2">
								<div class="card-header-child">
                            		<h5 style="flex: 0; margin-top: 0.5rem;">Latest Quiz Results</h5>
								</div>
								<div class="card-header-child">
									<select class="btn btn-secondary dropdown-toggle" name="state" id="maxRows" style="flex: 2; margin-top: 0.25rem;">
										 <option value="5000">Show ALL Rows</option>
										 <option value="6">5 Rows</option>
										 <option value="11">10 Rows</option>
										 <option value="16">15 Rows</option>
										 <option value="21">20 Rows</option>
										 <option value="51">50 Rows</option>
										 <option value="71">70 Rows</option>
										 <option value="101">100 Rows</option>
									</select>
								</div>
							</div>						
													
                            <div class="card-body">
                                <div class="table-responsive">
									<div class="container">
										<table class="table table-class" id= "table-id">
											<thead>
											  <tr>
												<th>ID</th>  
												<th>Quiz ID</th>
												<th>Quiz Title</th>
												<th>User</th>
												<th>Result</th>
												<th>Date</th>
												<th></th>
											  </tr>
											</thead>
											<tbody>
											  <tr>
												<?php

												require_once "config.php";
												$sql = ("SELECT * FROM `QuizAttempt` WHERE `organization`='" . $_SESSION['org'] . "' ORDER BY timestamp DESC , QuizAttemptID DESC");
												$result = $link->query($sql);
												$quizattempt = array();
												  if ($result->num_rows > 0) {
												  while ($row = mysqli_fetch_array($result)) {
													$quizattempt[] = $row;
													  echo "<tr>";
													   echo "<th>" . $row['QuizAttemptID'] . "</th>";	
													   echo "<th>" . $row['QuizID'] . "</th>";													  
													   echo "<td>" . $row['QuizTitle'] . "</td>";
													   echo "<td>" . $row['email'] . "</td>";
													   echo "<td>" . $row['result'] . "</td>";
													   echo "<td>" . $row['timestamp'] . "</td>";
													   echo "</tr>";
												  }
												} else {
												  echo "0 results";
												}
												   ?>
											</tbody>
										</table>
										
										<!-- Start Pagination -->
										<div class='pagination-container' >
											<nav>
											  <ul class="pagination">
												<li data-page="prev" >
													<span><a class="btn-2 btn-block btn-table popup-with-move-anim"> < </a><span class="sr-only">(current)</span></span>
												</li>
											   <!--	Here the JS Function Will Add the Rows -->
												<li data-page="next" id="prev">
											   		<span><a class="btn-2 btn-block btn-table popup-with-move-anim"> > </a><span class="sr-only">(current)</span></span>
												</li>
											  </ul>
											</nav>
										</div>
									</div> <!-- 		End of Container -->		
                                </div>						
                            </div>
                        </div>
                    </div>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script>
		          getPagination('#table-id');

		  /*					PAGINATION 
		  - on change max rows select options fade out all rows gt option value mx = 5
		  - append pagination list as per numbers of rows / max rows option (20row/5= 4pages )
		  - each pagination li on click -> fade out all tr gt max rows * li num and (5*pagenum 2 = 10 rows)
		  - fade out all tr lt max rows * li num - max rows ((5*pagenum 2 = 10) - 5)
		  - fade in all tr between (maxRows*PageNum) and (maxRows*pageNum)- MaxRows 
		  */
		 

function getPagination(table) {
  var lastPage = 1;

  $('#maxRows')
    .on('change', function(evt) {
      //$('.paginationprev').html('');						// reset pagination

     lastPage = 1;
      $('.pagination')
        .find('li')
        .slice(1, -1)
        .remove();
      var trnum = 0; // reset tr counter
      var maxRows = parseInt($(this).val()); // get Max Rows from select option

      if (maxRows == 5000) {
        $('.pagination').hide();
      } else {
        $('.pagination').show();
      }

      var totalRows = $(table + ' tbody tr').length; // numbers of rows
      $(table + ' tr:gt(0)').each(function() {
        // each TR in  table and not the header
        trnum++; // Start Counter
        if (trnum > maxRows) {
          // if tr number gt maxRows

          $(this).hide(); // fade it out
        }
        if (trnum <= maxRows) {
          $(this).show();
        } // else fade in Important in case if it ..
      }); //  was fade out to fade it in
      if (totalRows > maxRows) {
        // if tr total rows gt max rows option
        var pagenum = Math.ceil(totalRows / maxRows); // ceil total(rows/maxrows) to get ..
        //	numbers of pages
        for (var i = 1; i <= pagenum; ) {
          // for each page append pagination li
          $('.pagination #prev')
            .before(
              '<li data-page="' +
                i +
                '">\
								  <span> <a class="btn-2 btn-block btn-table popup-with-move-anim">' +
                i++ +
                '</a><span class="sr-only">(current)</span></span>\
								</li>'
            )
            .show();
        } // end for i
      } // end if row count > max rows
      $('.pagination [data-page="1"]').addClass('active'); // add active class to the first li
      $('.pagination li').on('click', function(evt) {
        // on click each page
        evt.stopImmediatePropagation();
        evt.preventDefault();
        var pageNum = $(this).attr('data-page'); // get it's number

        var maxRows = parseInt($('#maxRows').val()); // get Max Rows from select option

        if (pageNum == 'prev') {
          if (lastPage == 1) {
            return;
          }
          pageNum = --lastPage;
        }
        if (pageNum == 'next') {
          if (lastPage == $('.pagination li').length - 2) {
            return;
          }
          pageNum = ++lastPage;
        }

        lastPage = pageNum;
        var trIndex = 0; // reset tr counter
        $('.pagination li').removeClass('active'); // remove active class from all li
        $('.pagination [data-page="' + lastPage + '"]').addClass('active'); // add active class to the clicked
        // $(this).addClass('active');					// add active class to the clicked
	  	limitPagging();
        $(table + ' tr:gt(0)').each(function() {
          // each tr in table not the header
          trIndex++; // tr index counter
          // if tr index gt maxRows*pageNum or lt maxRows*pageNum-maxRows fade if out
          if (
            trIndex > maxRows * pageNum ||
            trIndex <= maxRows * pageNum - maxRows
          ) {
            $(this).hide();
          } else {
            $(this).show();
          } //else fade in
        }); // end of for each tr in table
      }); // end of on click pagination list
	  limitPagging();
    })
    .val(6)
    .change();

  // end of on select change

  // END OF PAGINATION
}

function limitPagging(){
	// alert($('.pagination li').length)

	if($('.pagination li').length > 7 ){
			if( $('.pagination li.active').attr('data-page') <= 3 ){
			$('.pagination li:gt(5)').hide();
			$('.pagination li:lt(5)').show();
			$('.pagination [data-page="next"]').show();
		}if ($('.pagination li.active').attr('data-page') > 3){
			$('.pagination li:gt(0)').hide();
			$('.pagination [data-page="next"]').show();
			for( let i = ( parseInt($('.pagination li.active').attr('data-page'))  -2 )  ; i <= ( parseInt($('.pagination li.active').attr('data-page'))  + 2 ) ; i++ ){
				$('.pagination [data-page="'+i+'"]').show();

			}
		}
	}
}
		</script>
					<?php

							require_once "config.php";
							$sqloct = ("SELECT AVG(`resultpercent`) FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN '2021-10-01' AND '2021-10-31' ORDER BY `timestamp` DESC");
							$resultoct = $link->query($sqloct);
							$successrateoct = array();

							if ($resultoct->num_rows > 0) {
							  while ($row = mysqli_fetch_array($resultoct)) {
								$successrateoct[] = $row;
							  }
								$currentsuccessrateoct = ($successrateoct[0][1]);
								$currentsuccessrateoct = var_export($successrateoct[0][1], true);
							} else {
							  $oct=0;
							}
							$oct=number_format((float)$successrateoct[0][0], 2, '.', '');  
							$sqlnov = ("SELECT AVG(`resultpercent`) FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN '2021-11-01' AND '2021-11-30' ORDER BY `timestamp` DESC");
							$resultnov = $link->query($sqlnov);
							$successratenov = array();
							if ($resultnov->num_rows > 0) {
							  while ($row = mysqli_fetch_array($resultnov)) {
								$successratenov[] = $row;
							  }
								$currentsuccessratenov = ($successratenov[0][1]);
								$currentsuccessratenov = var_export($successratenov[0][1], true);

							} else {
							  $nov=0;
							}

							$nov=number_format((float)$successratenov[0][0], 2, '.', '');					
							$sqldec = ("SELECT AVG(`resultpercent`) FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN '2021-12-01' AND '2021-12-31' ORDER BY `timestamp` DESC");
							$resultdec = $link->query($sqldec);
							$successratedec = array();

							if ($resultdec->num_rows > 0) {
							  while ($row = mysqli_fetch_array($resultdec)) {
								$successratedec[] = $row;
							  }
								$currentsuccessratedec = ($successratedec[0][1]);
								$currentsuccessratedec = var_export($successratedec[0][1], true);
							} else {
							  $dec=0;
							}
							 
							$dec=number_format((float)$successratedec[0][0], 2, '.', '');
					
							$sqljan = ("SELECT AVG(`resultpercent`) FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN '2022-01-01' AND '2022-01-31' ORDER BY `timestamp` DESC");
							$resultjan = $link->query($sqljan);
							$successratejan = array();

							if ($resultjan->num_rows > 0) {
							  while ($row = mysqli_fetch_array($resultjan)) {
								$successratejan[] = $row;
							  }
								$currentsuccessratejan = ($successratejan[0][1]);
								$currentsuccessratejan = var_export($successratejan[0][1], true);

							} else {
							  $jan=0;
							}
							 
							$jan=number_format((float)$successratejan[0][0], 2, '.', '');
					
							$sqlfeb = ("SELECT AVG(`resultpercent`) FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN '2022-02-01' AND '2022-02-28' ORDER BY `timestamp` DESC");
							$resultfeb = $link->query($sqlfeb);
							$successratefeb = array();

							if ($resultfeb->num_rows > 0) {
							  while ($row = mysqli_fetch_array($resultfeb)) {
								$successratefeb[] = $row;
							  }
								$currentsuccessratefeb = ($successratefeb[0][1]);
								$currentsuccessratefeb = var_export($successratefeb[0][1], true);
							} else {
							  $feb=0;
							}
							 
							$feb=number_format((float)$successratefeb[0][0], 2, '.', '');
					
							$sqlmar = ("SELECT AVG(`resultpercent`) FROM `QuizAttempt` WHERE `organization` ='" . $_SESSION['org'] . "' AND `timestamp` BETWEEN '2022-03-01' AND '2022-03-31' ORDER BY `timestamp` DESC");
							$resultmar = $link->query($sqlmar);
							$successratemar = array();

							if ($resultmar->num_rows > 0) {
							  while ($row = mysqli_fetch_array($resultmar)) {
								$successratemar[] = $row;
							  }
								$currentsuccessratemar = ($successratemar[0][1]);
								$currentsuccessratemar = var_export($successratemar[0][1], true);
							} else {
							  $mar=0;
							}
							 
							$mar=number_format((float)$successratemar[0][0], 2, '.', '');
							
				   ?>
					
					<table class="table" id="dataTable" hidden>
						  <thead>
							<th>Year</th>
							<th>Quiz Result</th>
						  </thead>
						  <tbody>
							<tr>
							  <td>Oct</td>
							  <td><?php echo htmlspecialchars($oct); ?></td>
							</tr>
							<tr>
							  <td>Nov</td>
							  <td><?php echo htmlspecialchars($nov); ?></td>
							</tr>  
							<tr>
							  <td>Dec</td>
							  <td><?php echo htmlspecialchars($dec); ?></td>
							</tr>
							<tr>
							  <td>Jan</td>
							  <td><?php echo htmlspecialchars($jan); ?></td>
							</tr>
							<tr>
							  <td>Feb</td>
							  <td><?php echo htmlspecialchars($feb); ?></td>
							</tr>
							<tr>
							  <td>Mar</td>
							  <td><?php echo htmlspecialchars($mar); ?></td>
							</tr>
						  </tbody>
						</table>
					
                    <div class="col-12 col-xl-4">
                        <div class="card">
                            <h5 class="card-header">Quiz Success Rate</h5>
                            <div class="card-body">
                                <div class="chart"><canvas id="myChart"></canvas></div>
                            </div>
                        </div>
                    </div>
					<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.js'></script>
					<script  src="js/chart.js"></script>
					
                </div>
                
            </main>
        </div>
    </div>
		
	
	</div>	
	<!-- Footer -->
	<footer id="footer">
		<div class="centerTextDiv bg-gray">
        <div class="container">
            <div class="row">
                <div class="col">
					<p class="p-small" style="margin-top:1rem"><a class="footer-link" href="privacy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> · <a class="footer-link" href="cookies.html" target="_blank" rel="noopener noreferrer">Cookie Policy</a></p>
					<p class="p-small">Assets gathered under <a class="footer-link" href="https://creativecommons.org/licenses/" target="_blank" rel="noopener noreferrer">Creative Commons Licenses</a> · Created for educational purposes only.</p>
                </div>
            </div>
        </div>
    </div>
	</footer>
	<!-- end of footer -->
	
	</div>
	
	<script> 
		filterSelection("all")
		function filterSelection(c) {
		  var x, i;
		  x = document.getElementsByClassName("trainingFilterDiv");
		  if (c == "all") c = "";
		  // Add the "show" class (display:block) to the filtered elements, and remove the "show" class from the elements that are not selected
		  for (i = 0; i < x.length; i++) {
			w3RemoveClass(x[i], "trainingBtnShow");
			if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "trainingBtnShow");
		  }
		}

		// Show filtered elements
		function w3AddClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			if (arr1.indexOf(arr2[i]) == -1) {
			  element.className += " " + arr2[i];
			}
		  }
		}

		// Hide elements that are not selected
		function w3RemoveClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			while (arr1.indexOf(arr2[i]) > -1) {
			  arr1.splice(arr1.indexOf(arr2[i]), 1);
			}
		  }
		  element.className = arr1.join(" ");
		}

		// Add active class to the current control button (highlight it)
		var btnContainer = document.getElementById("trainingBtnContainer");
		var btns = btnContainer.getElementsByClassName("trainingBtn");
		for (var i = 0; i < btns.length; i++) {
		  btns[i].addEventListener("click", function() {
			var current = document.getElementsByClassName("active");
			current[0].className = current[0].className.replace(" active", "");
			this.className += " active";
		  });
		}
	</script>
	
	
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    
	<script>
        new Chartist.Line('#traffic-chart', {
            labels: ['October', 'November', 'December', 'January', 'Februrary', 'March'],
            series: [
                [0, 20, 40, 60, 80, 100%]
            ]
            }, {
            low: 0,
            showArea: true
        });
    </script>
	
	<!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script>
	/* Description: Custom JS file */


	(function($) {
		"use strict"; 

		/* Navbar Scripts */
		// jQuery to collapse the navbar on scroll
		$(window).on('scroll load', function() {
			if ($(".navbar").offset().top > 60) {
				$(".fixed-top").addClass("top-nav-collapse");
			} else {
				$(".fixed-top").removeClass("top-nav-collapse");
			}
		});

		// jQuery for page scrolling feature - requires jQuery Easing plugin
		$(function() {
			$(document).on('click', 'a.page-scroll', function(event) {
				var $anchor = $(this);
				$('html, body').stop().animate({
					scrollTop: $($anchor.attr('href')).offset().top
				}, 600, 'easeInOutExpo');
				event.preventDefault();
			});
		});

		// offcanvas script from Bootstrap + added element to close menu on click in small viewport
		$('[data-toggle="offcanvas"], .navbar-nav li a:not(.dropdown-toggle').on('click', function () {
			$('.offcanvas-collapse').toggleClass('open')
		})

		// hover in desktop mode
		function toggleDropdown (e) {
			const _d = $(e.target).closest('.dropdown'),
				_m = $('.dropdown-menu', _d);
			setTimeout(function(){
				const shouldOpen = e.type !== 'click' && _d.is(':hover');
				_m.toggleClass('show', shouldOpen);
				_d.toggleClass('show', shouldOpen);
				$('[data-toggle="dropdown"]', _d).attr('aria-expanded', shouldOpen);
			}, e.type === 'mouseleave' ? 300 : 0);
		}
		$('body')
		.on('mouseenter mouseleave','.dropdown',toggleDropdown)
		.on('click', '.dropdown-menu a', toggleDropdown);


		/* Details Lightbox - Magnific Popup */
		$('.popup-with-move-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: true,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-slide-bottom'
		});


		/* Counter - CountTo */
		var a = 0;
		$(window).scroll(function() {
			if ($('#counter').length) { // checking if CountTo section exists in the page, if not it will not run the script and avoid errors	
				var oTop = $('#counter').offset().top - window.innerHeight;
				if (a == 0 && $(window).scrollTop() > oTop) {
				$('.counter-value').each(function() {
					var $this = $(this),
					countTo = $this.attr('data-count');
					$({
					countNum: $this.text()
					}).animate({
						countNum: countTo
					},
					{
						duration: 2000,
						easing: 'swing',
						step: function() {
							$this.text(Math.floor(this.countNum));
						},
						complete: function() {
							$this.text(this.countNum);
							//alert('finished');
						}
					});
				});
				a = 1;
				}
			}
		});

		/* Move Form Fields Label When User Types */
		// for input and textarea fields
		$("input, textarea").keyup(function(){
			if ($(this).val() != '') {
				$(this).addClass('notEmpty');
			} else {
				$(this).removeClass('notEmpty');
			}
		});


		/* Removes Long Focus On Buttons */
		$(".button, a, button").mouseup(function() {
			$(this).blur();
		});

	})(jQuery);
	</script> <!-- Custom scripts -->
	
</body>

</html>