<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait Campaign Guide"/>
	<meta property="og:description" content="Modern solutions to phishing attacks." />
	<meta property="og:image" content="images/PhishBait Logo Trimmed Glow.png" />
	<meta property="og:url" content="https://phishbait.org/campaign-guide.php" />
	<meta name="twitter:card" content="summary_large_image">


    <!-- Webpage Title -->
    <title>PhishBait - Campaign Guide</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    
    <div id="page-container">
		<div id="content-wrap">
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.php"><img src="images/PhishBait Logo Trimmed Glow.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
					<li class="nav-item">
                        <a class="nav-link page-scroll" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.php">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.php">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-videos.php">Training Videos</a>
                    </li>
					
					<li class="nav-item">
						<div class="dropdown">
						<button class="btn btn-outline-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
						  Hello, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>
						</button>
						<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						  <li><a class="dropdown-item" href="reset-password.php">Settings</a></li>
						  <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
						</ul>
					  </div>
					</li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Header -->
    <div class="header" style="height: 2vw">
        <div class="ocean" style="height: 2vw">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
    </div>
	
	
	<div class="centerTextDiv">
		<h1 class="h1-large" style="padding-bottom: 1em">Campaign Guide</h1>
		<br>
	</div>

	
	<div class="indexContainer">
	  <div class="indexFilterDiv">
			<div class="indexTextContainer" >
				<i class="fas fa-question-circle"></i>
				<h4>Delivery Method</h4>
				<p>When developing PhishBait, we maintained our goal of providing free-of-use training materials for phishing campaign simulations. To maintain this scope, we have not implemented a method of sending the campaign emails.</p>
			</div>
	  </div>
	  <div class="indexFilterDiv">
			<div class="indexTextContainer">
				<i class="fas fa-cogs"></i>
				<h4>Products and Services</h4>
				<p>There are many options available for sending out the campaign emails, including a few options below that we recommend.</p>
			</div>
	  </div>
	  <div class="indexFilterDiv">
			<div class="indexTextContainer">
				<i class="fas fa-bullseye"></i>
				<h4>Disclaimer</h4>
				<p>Please note: The products and services offered by the third-party companies below are in no way affiliated with PhishBait. These products and services are options we found while researching to assist in the delivery method of your phishing campaign.</p>
			</div>
	  </div>
	</div>
	
	
	<div class="centerTextDiv" style="padding-bottom: 4em" hidden="true">
		<div id="trainingBtnContainer" hidden="true">
		  <button class="trainingBtn active" onclick="filterSelection('all')" hidden="true"> Show all</button>
		</div>
		<div class="dropdown">
		  <button class="trainingBtn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" hidden="true">
			Filter Videos
		  </button>
		  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" hidden="true">
			<a class="dropdown-item" onclick="filterSelection('basics')" hidden="true"> Basics</a>
			<a class="dropdown-item" onclick="filterSelection('cat2')" hidden="true"> Cat2</a>
			<a class="dropdown-item" onclick="filterSelection('cat3')" hidden="true"> Cat3</a>
			<a class="dropdown-item" onclick="filterSelection('cat4')" hidden="true"> Cat4</a>
		  </div>
		</div>
	</div>

	<!-- The filterable elements. Note that some have multiple class names (this can be used if they belong to multiple categories) -->
	<div class="trainingContainer">
	<!-- Style option 1 -->
	  <div class="trainingFilterDiv">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/phishbait.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Using PhishBait Materials with 3rd Party Services</h4>
						<p>PhishBait makes 3rd party services easy to use by providing the email templates, training materials, and educational resources to make your campaign a success. Educational progress can be tracked through the Admin dashboard.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#campaign-lightbox-1">Learn More</a></div>
			</div>
	  </div>
		
	  <div class="trainingFilterDiv">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/cofense.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>CoFense</h4>
						<p>CoFense (formerly PhishMe) is a large scale provider for services related to phishing campaigns. CoFense's PhishMe tool allows administrators to send out phishing campaign emails using PhishBait's easy-to-use templates.  </p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#campaign-lightbox-2">Learn More</a></div>
			</div>
	  </div>
		
	<div class="trainingFilterDiv">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/gophish.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>GoPhish</h4>
						<p>GoPhish is an open-source phishing campaign simulation framework that is free to use. The initial installation and setup of the tool is the most time consuming part, but GoPhish makes it easy to simulate phishing attacks with just a click of a few buttons.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#campaign-lightbox-3">Learn More</a></div>
			</div>
	  </div>
	
		<div class="trainingFilterDiv">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/set.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Social-Engineer Toolkit</h4>
						<p>Social-Engineer Toolkit (SET) is a tool from TrustedSec that provides advanced options for simulating a phishing campaign, as well as other social engineering attacks. After PhishBait template using SET, our training videos and quizzes will help the users better understand social engineering and phishing.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#campaign-lightbox-4">Learn More</a></div>
			</div>
	  </div>
		
	</div>
	
    <!-- Lightboxes -->
    <!-- Example 1 -->
	<div id="campaign-lightbox-1" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-7" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/phishbaitlightbox.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-5">
                <h3>Using PhishBait</h3>
				<hr>
                <p>PhishBait's resources are easy to use with most phishing campaign services.</p>
                <h4>How to Use</h4>
                <p>Download email templates for use with one of the 3rd party services. Train and quiz your users. Monitor educational results.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Download and Send Template Library</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Detailed Training Modules</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">User Education Resources</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Easy progress monitoring</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="email-templates.php">Templates</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 2 -->
	<div id="campaign-lightbox-2" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-7" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/cofenselightbox.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-5">
                <h3>CoFense PhishMe</h3>
				<hr>
                <p>CoFense makes it easy to send out a phishing campaign using their PhishMe software. </p>
                <h4>Highlights</h4>
                <p>CoFense allows you to simulate phishing attacks at a low cost, using user-friendly software. Visit their website below to learn more about implementing their software.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Easy-to-use</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">$10-$12 per user per year</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Scalable for small to large organizations</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">User-friendly</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="https://cofense.com/product-services/phishme/" target="_blank" rel="noopener noreferrer">Visit CoFense</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 2 -->
		
    <!-- example 3 -->
	<div id="campaign-lightbox-3" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-7" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/gophishlightbox.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-5">
                <h3>GoPhish</h3>
				<hr>
                <p>GoPhish is an open-source project designed to run high-quality phishing campaigns with little effort and no cost.</p>
                <h4>Highlights</h4>
                <p>GoPhish takes some time to install and configure, but runs smoothly after the initial setup.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Open-source</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Download and Run</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Advanced options made simple</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Free to use</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="https://docs.getgophish.com/user-guide/" target="_blank" rel="noopener noreferrer">Visit GoPhish</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 3 -->
	
	<!-- example 4 -->
	<div id="campaign-lightbox-4" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-7" style="height:100%">
                <div class="image-container">
					<div>
						<img style="height:100%; width:100%; vertical-align: middle; " src="images/setlightbox.png" width="100%" alt="Placeholder Image"/>
					</div>
                </div>
			</div>
			<div class="col-lg-5">
                <h3>Social-Engineer Toolkit</h3>
				<hr>
                <p>TrustedSec created the Social-Engineer Toolkit (SET) as a penetration testing and social-engineering simulation tool. SET is the most advanced tool that we researched, with plenty of customization options.</p>
                <h4>Highlights</h4>
                <p>Social-Engineer Toolkit is an advanced simulation product, with an abundance of options.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Open-source</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Advanced Features</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Download and Run</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Free to use</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="https://www.trustedsec.com/tools/the-social-engineer-toolkit-set/" target="_blank" rel="noopener noreferrer">Visit SET</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 4 -->

    <!-- end of lightboxes -->
	
				
	
	<script> 
		filterSelection("all")
		function filterSelection(c) {
		  var x, i;
		  x = document.getElementsByClassName("trainingFilterDiv");
		  if (c == "all") c = "";
		  // Add the "show" class (display:block) to the filtered elements, and remove the "show" class from the elements that are not selected
		  for (i = 0; i < x.length; i++) {
			w3RemoveClass(x[i], "trainingBtnShow");
			if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "trainingBtnShow");
		  }
		}

		// Show filtered elements
		function w3AddClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			if (arr1.indexOf(arr2[i]) == -1) {
			  element.className += " " + arr2[i];
			}
		  }
		}

		// Hide elements that are not selected
		function w3RemoveClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			while (arr1.indexOf(arr2[i]) > -1) {
			  arr1.splice(arr1.indexOf(arr2[i]), 1);
			}
		  }
		  element.className = arr1.join(" ");
		}

		// Add active class to the current control button (highlight it)
		var btnContainer = document.getElementById("trainingBtnContainer");
		var btns = btnContainer.getElementsByClassName("trainingBtn");
		for (var i = 0; i < btns.length; i++) {
		  btns[i].addEventListener("click", function() {
			var current = document.getElementsByClassName("active");
			current[0].className = current[0].className.replace(" active", "");
			this.className += " active";
		  });
		}
	</script>



    </div> <!-- end of content-wrap -->
	<!-- Footer -->
	<footer id="footer">
		<div class="centerTextDiv bg-gray">
        <div class="container">
            <div class="row">
                <div class="col">
					<p class="p-small" style="margin-top:1rem"><a class="footer-link" href="privacy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> · <a class="footer-link" href="cookies.html" target="_blank" rel="noopener noreferrer">Cookie Policy</a></p>
					<p class="p-small">Assets gathered under <a class="footer-link" href="https://creativecommons.org/licenses/" target="_blank" rel="noopener noreferrer">Creative Commons Licenses</a> · Created for educational purposes only.</p>
                </div>
            </div>
        </div>
    </div>
	</footer>
	<!-- end of footer -->
		
	</div><!-- end of page container -->
    
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>