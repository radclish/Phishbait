<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Modern solutions to phishing attacks. Coming soon.">
    <meta name="developer" content="PhishBait Team">
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Home"/>
	<meta property="og:description" content="Modern solutions to phishing attacks. Coming soon." />
	<meta property="og:image" content="images/infohook.jpg" />
	<meta property="og:url" content="https://phishbait.org/" />
	<meta name="twitter:card" content="summary_large_image">

    <title>PhishBait</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
    <link rel="icon" href="images/favicon.png">
	
</head>
<body data-spy="scroll" data-target=".fixed-top">
    
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            
            <!-- Text Logo 
             <a class="navbar-brand logo-text page-scroll" href="index.html">PhishBait</a>
			-->
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.html"><img src="images/PhishBait Logo Slim.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
					<li class="nav-item">
                        <a class="nav-link page-scroll" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.php">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.php">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-videos.php">Training Videos</a>
                    </li>
					
					<!--
					<li class="nav-item">
                        <form class="d-inline">
							<a class="btn btn-outline-success" href="login.php" role="button">Sign In</a>
		  				</form>
                    </li>
					-->
					<li class="nav-item">
						<div class="dropdown">
						<button class="btn btn-outline-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
						  Hello, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>
						</button>
						<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						  <li><a class="dropdown-item" href="reset-password.php">Settings</a></li>
						  <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
						</ul>
					  </div>
					</li>
                </ul>
            </div>
        </div>
    </nav>
	
	
	
	

    <!-- Header -->
    <div class="header">
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="text-container">
                        <h1 class="h1-large">The Future of <br> Phishing Awareness</h1>
                        <p class="p-large">Modern solutions to phishing attacks<br>Find out how to fight back against these phishing schemes</p>
                        <a class="btn-solid-lg page-scroll" href="#statement">Learn More</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image-container">
                        <img class="img-fluid" src="images/infohook.png" alt="Info Hook Icon">
                    </div>
                </div>
            </div>
        </div>
    </div>


	<div class="indexContainer">
	  <div class="indexFilterDiv">
			<div class="indexTextContainer" >
				<i class="fas fa-question-circle"></i>
				<h4>What</h4>
				<p>Phishing is a cyber-attack where the target or targets receive a fraudulent email, text message, or phone call from the attacker who is posing as a legitimate entity to lure their targets into revealing personal information, such as credit card information or passwords</p>
			</div>
	  </div>
	  <div class="indexFilterDiv">
			<div class="indexTextContainer">
				<i class="fas fa-cogs"></i>
				<h4>How</h4>
				<p>The most common type of phishing attack is delivered through email. The sender generally poses as a legitimate company and tries to pry personal information out of their target using shock tactics. The email could pretend to be from your bank or a social media site. The goal of the email is to trick the user into clicking the link which will lead them into a fake website pretending to be the legitimate company. The user then logs in which gives the attackers the user’s login information.</p>
			</div>
	  </div>
	  <div class="indexFilterDiv">
			<div class="indexTextContainer">
				<i class="fas fa-bullseye"></i>
				<h4>Why</h4>
				<p>Phishing is so effective because users lack security awareness. Attackers will also rely on the sense of surprise. Not all users know what phishing is, so they don’t even know they are potential targets. Attackers will pick a time, such as work, where users are distracted. This gives attackers a better chance to catch a user in a phishing scheme.</p>
			</div>
	  </div>
	</div>	
	

    <!-- Details 2 -->
    <div id="EmailTemplates" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-5">
                    <div class="text-container">
                        <h2>Email Templates</h2>
                        <p>The Email Templates page contains a variety of specialized phishing email templates. The topics of the templates range from free downloads to shopping sites, making phising emails using them more enticing. These email templates will: </p>
                        <ul class="list-unstyled li-space-lg">
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Make sending out phising campaigns in your company easier</strong> </div>
                            </li>
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Help you send out more accurate phising campaigns</strong> </div>
                            </li>
                        </ul> 
                        <a class="btn-solid-reg" href="email-templates.php">Details</a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-7">
                    <div class="image-container-center">
                        <img class="img-fluid" src="images/emailTemplates.svg" alt="Email Templates Icon" style="filter: drop-shadow(-2px 4px 4px #585858)">
                    </div>
                </div>
            </div>
        </div>
    </div>
	
    <!-- Details 3 -->
    <div id="TrainingVideos" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-7">
                    <div class="image-container-center">
                        <img class="img-fluid" src="images/trainingVideos.svg" alt="Training Videos Icon" style="filter: drop-shadow(-2px 4px 4px #585858)">
                    </div>
                </div>
                <div class="col-lg-6 col-xl-5">
                    <div class="text-container">
                        <h2>Training Videos</h2>
                        <p>The Training Videos page contains a variety of training videos on phishing corosponding to the specific email templates.This is where employees will go after falling for a phising campaign sent out, or where they can go to better understand what phishing is. These videos will: </p>
                        <ul class="list-unstyled li-space-lg">
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Train employees on the dangers of phishing and how to prevent an attack  </strong></div>
                            </li>
                            <li class="media">
                                <i class="fas fa-square"></i>
                                <div class="media-body"><strong>Provide better security for your company from phising attacks</strong> </div>
                            </li>
                        </ul> 
                        <a class="btn-solid-reg popup-with-move-anim" href="training-videos.php">Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Invitation -->
    <div class="basic-6" style="background: #102a43">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container">
                        <h2 style="color: #FFFFFF">Who can use this information?</h2>
						<p style="color: #FFFFFF">Information about content limitations and account creation goes here.</p>
                        <a class="btn-solid-lg" href="dashboard.php">Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<!-- Contact -->
    <div id="contact" class="form-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="h2-heading">Contact Us:</h2>
                    <p class="p-heading">Questions? Feel free to reach out through the contact form or <a class="blue no-line" href="mailto:team@phishbait.org">team@phishbait.org</a></p>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-container"> 
                        <form method="post" action="messagereceived.php">
                            <div class="form-group">
                                <input type="text" class="form-control-input" id="contactname" required>
                                <label class="label-control" for="contactname" name="contactname">Name</label>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control-input" id="contactemail" required>
                                <label class="label-control" for="contactemail" name="contactemail">Email</label>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control-textarea" id="contactmessage" required></textarea>
                                <label class="label-control" for="contactmessage" name="contactmessage">Your message</label>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="form-control-submit-button">Submit Message</button>
                            </div>
                        </form>
                    </div>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of form-1 -->
    <!-- end of contact -->
	
    <div class="basic-6" style="background: #102a43">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container">
                        <h2 style="color: #FFFFFF">IT Expo 2022</h2>
						<h3 id="demo" style="color: #FFFFFF"></h3>

						<script>
						var countDownDate = new Date("Apr 12, 2022 09:00:00").getTime();
						var x = setInterval(function() {
						  var now = new Date().getTime();
						  var distance = countDownDate - now;
						  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
						  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
						  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
						  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
						  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
						  + minutes + "m " + seconds + "s ";
						  if (distance < 0) {
							clearInterval(x);
							document.getElementById("demo").innerHTML = "EXPIRED";
						  }
						}, 1000);
						</script>
                    </div>
                </div>
			</div>
        </div>
    </div>
	
	
	
    <!-- Footer -->
    <div class="footer bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
					<p class="p-small">Copyright © <a class="no-line" href="#your-link">PhishBait</a></p>
					<p class="p-small">Assets gathered under Creative Commons License</p>
                </div>
            </div>
        </div>
    </div>  
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>
