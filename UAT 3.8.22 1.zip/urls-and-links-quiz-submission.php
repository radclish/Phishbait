 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks. Coming soon.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Create an Account"/>
	<meta property="og:description" content="Modern solutions to phishing attacks. Coming soon." />
	<meta property="og:image" content="images/infohook.jpg" />
	<meta property="og:url" content="https://phishbait.org/signup.html" />
	<meta name="twitter:card" content="summary_large_image">


    <!-- Webpage Title -->
    <title>PhishBait</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    <center>
        <?php
  		require_once "config.php";
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        //$conn = mysqli_connect("localhost", "root", "", "staff");
          
        // Check connection
        if($link === false){
            die("ERROR: Could not connect. " 
                . mysqli_connect_error());
        }
          
        // Taking all 5 values from the form data(input)
        $firstname =  $_REQUEST['firstname'];
        $lastname = $_REQUEST['lastname'];
        $email =  $_REQUEST['email'];
        $organization = $_REQUEST['organization'];
		$response1 = $_REQUEST['question-1-answers'];
		$response2 = $_REQUEST['question-2-answers'];
		$response3 = $_REQUEST['question-3-answers'];
		$response4 = $_REQUEST['question-4-answers'];
		$response5 = $_REQUEST['question-5-answers'];
		$response6 = $_REQUEST['question-6-answers'];
		$response7 = $_REQUEST['question-7-answers'];
		$response8 = $_REQUEST['question-8-answers'];
		$response9 = $_REQUEST['question-9-answers'];
        
            $totalCorrect = 0;
            
            if ($response1 == "B") { $totalCorrect++; }
            if ($response2 == "C") { $totalCorrect++; }
            if ($response3 == "A") { $totalCorrect++; }
			if ($response4 == "B") { $totalCorrect++; }
			if ($response5 == "A") { $totalCorrect++; }
			if ($response6 == "C") { $totalCorrect++; }
			if ($response7 == "A") { $totalCorrect++; }
			if ($response8 == "B") { $totalCorrect++; }
			if ($response9 == "A") { $totalCorrect++; }
            
            //echo "<div id='results'>$totalCorrect / 3 correct</div>";
            
        $result = "$totalCorrect/9";
		$resultdecimal = $totalCorrect/9;
		$resultdecimalfloat = number_format((float)$resultdecimal, 2, '.', '');
		$resultpercent = $resultdecimalfloat*100;
		
          
        // Performing insert query execution
        $sql = "INSERT INTO QuizAttempt (QuizID, QuizTitle, firstname, lastname, email, organization, response1, response2, response3, response4, response5, response6, response7, response8, response9, result, resultdecimal, resultpercent)  VALUES (3,'Defining and Explaining Terms Quiz','$firstname', '$lastname','$email','$organization','$response1','$response2','$response3','$response4','$response5','$response6','$response7','$response8','$response9','$result','$resultdecimal','$resultpercent')";
          
        if(mysqli_query($link, $sql)){
            //echo "<h3>data stored in a database successfully." 
                //. " Please browse your localhost php my admin" 
                //. " to view the updated data</h3>"; 
  
            //echo nl2br("\n$firstname\n $lastname\n "
                //. "$email\n $organization"
				//. "$response1\n $response2\n $response3");
			
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($link);
        }
          
        // Close connection
        mysqli_close($link);
        ?>
    </center>
	
	
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            
            <!-- Text Logo 
             <a class="navbar-brand logo-text page-scroll" href="index.html">PhishBait</a>
			-->
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.html"><img src="images/PhishBait Logo Slim.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.html" style="display: none;">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.html">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-videos.html">Training Videos</a>
                    </li>
					<li class="nav-item">
                        <form class="d-inline">
							<a class="btn btn-outline-success" href="login.php" role="button">Sign In</a>
		  				</form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Header -->
    <div class="header">
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
		<div class="w-full text-center p-t-55">
			<h2 style="color: #FFFFFF">Quiz Submitted!</h2>
			<p style="color: #FFFFFF">Score: <?php echo htmlspecialchars($result); ?></p>
		</div>
        <div class="container">
            <div class="row">
				<div class="col" style="text-align: end">
				  <a class="btn-solid-lg page-scroll" href="urls-and-links-quiz.php">Retake</a>
				</div>
				<div class="col">
				  <a class="btn-solid-lg page-scroll" href="training-videos.html">Complete</a>
				</div>
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of header -->
	
	
</body>
</html>