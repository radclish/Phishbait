<?php
// Include config file
require_once "config.php";

$sql = "SELECT QuestionID, Text, QuizID FROM QuizQuestions WHERE QuizID = 1";
$result = $link->query($sql);
$questions = array();

if ($result->num_rows > 0) {
  // output data of each row
  while ($row = mysqli_fetch_array($result)) {
    $questions[] = $row;
  }
	//var_dump($questions);

} else {
  echo "0 results";
}

$sql2 = "SELECT AnswerID, Text, QuizID, QuestionID, Correct FROM QuizAnswers WHERE QuizID = 1";
$result2 = $link->query($sql2);
$answers = array();

if ($result2->num_rows > 0) {
  // output data of each row
  while ($row = mysqli_fetch_array($result2)) {
    $answers[] = $row;
  }
	//var_dump($questions);
	
	

} else {
  echo "0 results";
}

$sql3 = "SELECT QuizID, Title FROM Quiz WHERE QuizID = 1";
$result3 = $link->query($sql3);
$quiztitle = array();

if ($result3->num_rows > 0) {
  // output data of each row
  while ($row = mysqli_fetch_array($result3)) {
    $quiztitle[] = $row;
  }
	//var_dump($questions);
	$currentQuizTitle = ($quiztitle[0][1]);
	$currentQuizTitle = var_export($quiztitle[0][1], true);
	//echo $currentQuizTitle;

} else {
  echo "0 results";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Introduction Quiz"/>
	<meta property="og:description" content="Modern solutions to phishing attacks." />
	<meta property="og:image" content="images/PhishBait Logo Trimmed Glow.png" />
	<meta property="og:url" content="https://phishbait.org/introduction-quiz.php" />
	<meta name="twitter:card" content="summary_large_image">


    <!-- Webpage Title -->
    <title>PhishBait - Introduction Quiz</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    <div id="page-container">
		<div id="content-wrap">
    
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.html"><img src="images/PhishBait Logo Trimmed Glow.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.html" style="display: none;">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.html">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-videos.html">Training Videos</a>
                    </li>
					<li class="nav-item">
                        <form class="d-inline">
							<a class="btn btn-outline-success" href="login.php" role="button">Sign In</a>
		  				</form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Header -->
    <div class="header">
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
		<div class="w-full text-center p-t-55">
			<h2 style="color: #FFFFFF">Quiz Attempt</h2>
			<p style="color: #FFFFFF">Please fill in your information to complete the quiz.</p>
		</div>
        <div class="container">
            <div class="row">
				<form name="f1" action="introduction-quiz-submission.php" method="post">
					<div class="mb-3">
						<label class="form-label" style="color: #FFFFFF">First Name</label>
						<input type="text" name="firstname" class="form-control" id="firstName" required="First name is required.">
					</div>
					<div class="mb-3">
						<label class="form-label" style="color: #FFFFFF">Last Name</label>
						<input type="text" name="lastname" class="form-control" id="lastname" required>
					</div>
					<div class="mb-3">
						<label class="form-label" style="color: #FFFFFF">Email Address</label>
						<input type="text" name="email" class="form-control" id="email" required>
					</div>
            		<div class="mb-3">
						<label class="form-label" style="color: #FFFFFF">Organization</label>
						<input type="text" name="organization" class="form-control" id="organization" required>
					</div>	
				
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of header -->

	 <div class="centerTextDiv" id="page-wrap">
 		<h1><?php echo htmlspecialchars($quiztitle[0][1]); ?></h1>
	</div>
		
	<div style="padding: 5% 25% 5% 25%">
 	<!-- <form action="result.php" method="post" id="quiz"> -->
    	<div class="form-group">
                    <h3>1.<?php echo htmlspecialchars($questions[0][1]); ?></h3> <!-- quiz title -->
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-A" value="A" />
                        <label for="question-1-answers-A" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">A)&nbsp;<?php echo htmlspecialchars($answers[0][1]); ?> </label>
                    </div>
                
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-B" value="B" />
                        <label for="question-1-answers-B" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">B)&nbsp;<?php echo htmlspecialchars($answers[1][1]); ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">C)&nbsp;<?php echo htmlspecialchars($answers[2][1]); ?></label>
                    </div>
                    
		</div>
                
                
       	<div class="form-group">    
                
                    <h3>2.<?php echo htmlspecialchars($questions[1][1]); ?></h3>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-A" value="A" />
                        <label for="question-2-answers-A" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">A)&nbsp;<?php echo htmlspecialchars($answers[3][1]); ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-B" value="B" />
                        <label for="question-2-answers-B" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">B)&nbsp;<?php echo htmlspecialchars($answers[4][1]); ?></label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-2-answers-C" value="C" />
                        <label for="question-2-answers-C" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">C)&nbsp;<?php echo htmlspecialchars($answers[5][1]); ?></label>
                    </div>
                    
                
		</div>
        <div class="form-group">   
                    <h3>3.<?php echo htmlspecialchars($questions[2][1]); ?></h3>
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-A" value="A" />
                        <label for="question-3-answers-A" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">A)&nbsp;<?php echo htmlspecialchars($answers[6][1]); ?></label>
                    </div>
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-B" value="B" />
                        <label for="question-3-answers-B" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">B)&nbsp;<?php echo htmlspecialchars($answers[7][1]); ?></label>
                    </div>
                    <div>
                        <input type="radio" name="question-3-answers" id="question-3-answers-C" value="C" />
                        <label for="question-3-answers-C" style="font: 400 1.5rem/2rem Open Sans, sans-serif;">C)&nbsp;<?php echo htmlspecialchars($answers[8][1]); ?></label>
                    </div>
		</div>
       </div>
            <!--<input type="submit" value="Submit" class="submitbtn" />-->
			<!--<div class="centerTextDiv"><a class="btn-solid-reg-no-shadow popup-with-move-anim" type="submit" value="Submit" href="#">Submit</a></div>-->
				<!--<div class="centerTextDiv"><input type="submit" value="Submit" class="btn-solid-reg-no-shadow popup-with-move-anim" /></div>-->
		<!--<div class="centerTextDiv" style="padding-bottom: 5%;"><input type="submit" value="Submit"></div>-->
		<div class="centerTextDiv" style="padding-bottom: 5%;">
			<input type="submit" value="Submit">
		</div>
 </form>
	
    </div> <!-- end of content-wrap -->
	<!-- Footer -->
	<footer id="footer">
		<div class="centerTextDiv bg-gray">
        <div class="container">
            <div class="row">
                <div class="col">
					<p class="p-small" style="margin-top:1rem"><a class="footer-link" href="privacy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> · <a class="footer-link" href="cookies.html" target="_blank" rel="noopener noreferrer">Cookie Policy</a></p>
					<p class="p-small">Assets gathered under <a class="footer-link" href="https://creativecommons.org/licenses/" target="_blank" rel="noopener noreferrer">Creative Commons Licenses</a> · Created for educational purposes only.</p>
                </div>
            </div>
        </div>
    </div>
	</footer>
	<!-- end of footer -->
		
	</div><!-- end of page container -->
    
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>