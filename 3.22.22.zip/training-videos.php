<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Modern solutions to phishing attacks.">
    <meta name="developer" content="PhishBait Team">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="PhishBait" />
	<meta property="og:site" content="phishbait.org" />
	<meta property="og:title" content="PhishBait - Training Videos"/>
	<meta property="og:description" content="Modern solutions to phishing attacks." />
	<meta property="og:image" content="images/PhishBait Logo Trimmed Glow.png" />
	<meta property="og:url" content="https://phishbait.org/training-videos.php" />
	<meta name="twitter:card" content="summary_large_image">


    <!-- Webpage Title -->    
    <title>PhishBait - Training Videos</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    <div id="page-container">
		<div id="content-wrap">
    <!-- Nav -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            <!-- Image Logo -->
             <a class="navbar-brand logo-image page-scroll" href="index.php"><img src="images/PhishBait Logo Trimmed Glow.png" alt="alternative" style="height:100%"></a>

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">			
					<li class="nav-item">
                        <a class="nav-link page-scroll" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="campaign-guide.php">Campaign Guide</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="email-templates.php">Email Templates</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="training-videos.php">Training Videos</a>
                    </li>
					<li class="nav-item">
						<div class="dropdown">
						<button class="btn btn-outline-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-expanded="false">
						  Hello, <?php echo htmlspecialchars($_SESSION["firstname"]); ?>
						</button>
						<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						  <li><a class="dropdown-item" href="reset-password.php">Settings</a></li>
						  <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
						</ul>
					  </div>
					</li>
                </ul>
            </div>
        </div>
    </nav>
            
    <div class="headerSmall" style="height: 2vw">
        <div class="ocean" style="height: 2vw">
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
    </div>
	
	<div class="centerTextDiv">
		<h1 class="h1-large" style="padding-bottom: 1em">Training Videos</h1>
	</div>
	<div class="centerTextDiv" style="padding-bottom: 1em">
		<p class="p-large" style="width:50%">Our training videos allow users to access custom made training material designed to provide general phishing awareness training, as well as specialized content to accompany our email templates.
		<br><br>Choose from one of the videos below, and click on the learn more to start the training module.</p>
	</div>
	
	<div class="trainingContainer">
	<!-- Style option 1 -->
	  <div class="trainingFilterDiv basics">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/introduction.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Module 1</h4>
						<h4>Introduction to Phishing</h4>
						<p>This is the first in a series of video training modules. You will learn what phishing is on a basic level so that individuals with varying levels of technical knowledge will understand.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#video-lightbox-1">Start Training</a></div>
			</div>
	  </div>
		
	  <div class="trainingFilterDiv cat2">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/urlsandlinks.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Module 2</h4>
						<h4>URLs and Links</h4>
						<p>This is the second in a series of video training modules. You will learn what a URL is along with its components and what hidden links are.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#video-lightbox-2">Start Training</a></div>
			</div>
	  </div>
	<!-- end of style option 1 -->
	  <div class="trainingFilterDiv basics cat3">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/typesofphishing.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Module 3</h4>
						<h4>Types of Phishing</h4>
						<p>This is the third in a series of video training modules. You will learn about a multitude of different phishing types.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#video-lightbox-3">Start Training</a></div>
			</div>
	  </div>
		
	  <div class="trainingFilterDiv cat2 cat4">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/phishingemailexamples.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Module 4</h4>
						<h4>Phishing Email Examples</h4>
						<p>This is the fourth in a series of video training modules. You will learn how to identify a phishing email along with multiple phishing email examples.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#video-lightbox-4">Start Training</a></div>
			</div>
	  </div>
	  <div class="trainingFilterDiv cat2 cat4">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/techniquesandbestpractices.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Module 5</h4>
						<h4>Techniques and Best Practices</h4>
						<p>This is the fifth in a series of video training modules. You will learn a multitude of techniques and best practices to avoid phishing schemes.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#video-lightbox-5">Start Training</a></div>
			</div>
	  </div>
	  <div class="trainingFilterDiv cat1 cat3">
			<div class="trainingTextContainer">
				<div class="row">
					<div class="col-md" style="display: flex; align-items: center">
						<img style="margin: 0px 0px 15px 0px; width:100%; vertical-align: middle; " src="images/reviewandconclusion.png" width="100%" alt="Placeholder Image"/>
					</div>
				</div>
				<div class="row">
					<div class="col-md">
						<h4>Module 6</h4>
						<h4>Review and Conclusion</h4>
						<p>This is the sixth in a series of video training modules. You will learn the general overview of all the previous videos in this training module.</p>
					</div>
				</div>
				<div class="trainingButtonContainer"><a class="btn-solid-reg-no-shadow popup-with-move-anim" href="#video-lightbox-6">Start Training</a></div>
			</div>
	  </div>
	</div>
	
    <!-- Lightboxes -->
    <!-- Example 1 -->
	<div id="video-lightbox-1" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<iframe width="100%" height="500vw" src="https://www.youtube-nocookie.com/embed/jFpuvuU-mHM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Phishing Introduction</h3>
				<hr>
                <p>This is the first in a series of video training modules. You will learn what phishing is on a basic level so that individuals with varying levels of technical knowledge will understand. </p>
                <h5>Things You Will Learn About</h5>
                <p>This video goes over an introduction to phishing.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Social Engineering</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Phishing</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Types of Phishing</div>
                    </li>
                </ul>
				<a class="btn-solid-reg-no-shadow page-scroll" href="introduction-quiz.php">Quiz</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 2 -->
		<div id="video-lightbox-2" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<iframe width="100%" height="500vw" src="https://www.youtube-nocookie.com/embed/bL73CkUB-do" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>URLs and Links</h3>
				<hr>
                <p>This is the second in a series of video training modules. You will learn what a URL is along with its components and what hidden links are.</p>
                <h5>Things You Will Learn About</h5>
                <p>This video goes over URLs and Links.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">URLs</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Components of a URL</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Hidden Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Complicated Links</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="urls-and-links-quiz.php">Quiz</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 2 -->
		<div id="video-lightbox-3" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<iframe width="100%" height="500vw" src="https://www.youtube-nocookie.com/embed/vH-sQMnlBIs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Types of Phishing</h3>
				<hr>
                <p>This is the third in a series of video training modules. You will learn about a multitude of different phishing types.</p>
                <h5>Things You Will Learn About</h5>
                <p>This video goes over different types of phishing.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Email Phishing</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Spear Phishing</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Whaling</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Clone Phishing</div>
                    </li>
					<li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Vishing</div>
                    </li>
					<li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Smishing</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="types-of-phishing-quiz.php">Quiz</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 3 -->
	<div id="video-lightbox-4" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<iframe width="100%" height="500vw" src="https://www.youtube-nocookie.com/embed/Ml4E9T4iV-w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Phishing Email Examples</h3>
				<hr>
                <p>This is the fourth in a series of video training modules. You will learn how to identify a phishing email along with multiple phishing email examples.</p>
                <h5>Things You Will Learn About</h5>
                <p>This video goes over ways to identify phishing emails along with examples.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Phishing Email Examples</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">What to Look for in Potential Phishing Emails</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="phishing-email-examples-quiz.php">Quiz</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
	<div id="video-lightbox-5" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<iframe width="100%" height="500vw" src="https://www.youtube-nocookie.com/embed/3DFrO_VANLM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Techniques and Best Practices</h3>
				<hr>
                <p>This is the fifth in a series of video training modules. You will learn a multitude of techniques and best practices to avoid phishing schemes.</p>
                <h5>Things You Will Learn About</h5>
                <p>This video goes over the techniques and best practices to avoid phishing schemes.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Latest Phishing Scams</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Email Filtering</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Multifactor Authentication</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Browser Alerts</div>
                    </li>
					<li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Personal Information</div>
                    </li>
					<li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Password Managers</div>
                    </li>
					<li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Encryption</div>
                    </li>
					<li class="media">
                        <i class="fas fa-check"></i><div class="media-body">What If Scenarios</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="best-practices-quiz.php">Quiz</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
	<div id="video-lightbox-6" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8" style="height:100%">
                <div class="image-container">
					<div>
						<iframe width="100%" height="500vw" src="https://www.youtube-nocookie.com/embed/KmtLJcZ7U8g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
                </div>
			</div>
			<div class="col-lg-4">
                <h3>Review and Conclusion</h3>
				<hr>
                <p>This is the sixth in a series of video training modules. You will learn the general overview of all the previous videos in this training module.</p>
                <h5>Things You Will Learn About</h5>
                <p>This video goes over a review and a conclusion to this training module.</p>
                <ul class="list-unstyled li-space-lg">
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Introduction to Phishing</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">URL and Links</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Types of Phishing</div>
                    </li>
                    <li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Phishing Email Examples</div>
                    </li>
					<li class="media">
                        <i class="fas fa-check"></i><div class="media-body">Techniques and Best Practices</div>
                    </li>
                </ul>
                <a class="btn-solid-reg-no-shadow page-scroll" href="conclusion-quiz.php">Quiz</a> <button class="btn-outline-reg mfp-close as-button" type="button">Back</button>
			</div>
		</div>
    </div>
    <!-- end of example 4 -->

    <!-- end of lightboxes -->
	
				
	
	<script> 
		filterSelection("all")
		function filterSelection(c) {
		  var x, i;
		  x = document.getElementsByClassName("trainingFilterDiv");
		  if (c == "all") c = "";
		  // Add the "show" class (display:block) to the filtered elements, and remove the "show" class from the elements that are not selected
		  for (i = 0; i < x.length; i++) {
			w3RemoveClass(x[i], "trainingBtnShow");
			if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "trainingBtnShow");
		  }
		}

		// Show filtered elements
		function w3AddClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			if (arr1.indexOf(arr2[i]) == -1) {
			  element.className += " " + arr2[i];
			}
		  }
		}

		// Hide elements that are not selected
		function w3RemoveClass(element, name) {
		  var i, arr1, arr2;
		  arr1 = element.className.split(" ");
		  arr2 = name.split(" ");
		  for (i = 0; i < arr2.length; i++) {
			while (arr1.indexOf(arr2[i]) > -1) {
			  arr1.splice(arr1.indexOf(arr2[i]), 1);
			}
		  }
		  element.className = arr1.join(" ");
		}

		// Add active class to the current control button (highlight it)
		var btnContainer = document.getElementById("trainingBtnContainer");
		var btns = btnContainer.getElementsByClassName("trainingBtn");
		for (var i = 0; i < btns.length; i++) {
		  btns[i].addEventListener("click", function() {
			var current = document.getElementsByClassName("active");
			current[0].className = current[0].className.replace(" active", "");
			this.className += " active";
		  });
		}
	</script>

    </div> <!-- end of content-wrap -->
	<!-- Footer -->
	<footer id="footer">
		<div class="centerTextDiv bg-gray">
        <div class="container">
            <div class="row">
                <div class="col">
					<p class="p-small" style="margin-top:1rem"><a class="footer-link" href="privacy.html" target="_blank" rel="noopener noreferrer">Privacy Policy</a> · <a class="footer-link" href="cookies.html" target="_blank" rel="noopener noreferrer">Cookie Policy</a></p>
					<p class="p-small">Assets gathered under <a class="footer-link" href="https://creativecommons.org/licenses/" target="_blank" rel="noopener noreferrer">Creative Commons Licenses</a> · Created for educational purposes only.</p>
                </div>
            </div>
        </div>
    </div>
	</footer>
	<!-- end of footer -->
		
	</div><!-- end of page container -->
    
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>
